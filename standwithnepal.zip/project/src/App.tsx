import React, { useState, useEffect } from 'react';
import { Home, MessageSquare, Eye, BarChart3, User, LogOut, MapPin, Calendar, Users, TrendingUp, Settings } from 'lucide-react';
import ErrorBoundary from './components/ErrorBoundary';
import LoadingSpinner from './components/LoadingSpinner';
import { useLocalStorage } from './hooks/useLocalStorage';
import { User as UserType } from './types';
import HomePage from './components/HomePage';
import ReportIssue from './components/ReportIssue';
import ViewIssues from './components/ViewIssues';
import Analytics from './components/Analytics';
import GovernmentDashboard from './components/GovernmentDashboard';
import AdminDashboard from './components/AdminDashboard';
import AuthModal from './components/AuthModal';
import UserProfile from './components/UserProfile';
import NotificationSystem from './components/NotificationSystem';
import Dashboard from './components/Dashboard';

function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [user, setUser] = useLocalStorage<UserType | null>('nepal_platform_user', null);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showUserProfile, setShowUserProfile] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Simulate initial loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    return () => clearTimeout(timer);
  }, []);

  const handleLogin = (userData: UserType) => {
    setUser(userData);
    setShowAuthModal(false);
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentPage('home');
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage user={user} />;
      case 'dashboard':
        return user ? <Dashboard user={user} /> : <HomePage user={user} />;
      case 'report':
        return <ReportIssue user={user} />;
      case 'issues':
        return <ViewIssues user={user} />;
      case 'analytics':
        return <Analytics user={user} />;
      case 'government':
        return <GovernmentDashboard user={user} />;
      case 'admin':
        return <AdminDashboard user={user} />;
      default:
        return <HomePage user={user} />;
    }
  };

  const getNavItems = () => {
    const baseItems = [
      { id: 'home', label: 'Home', icon: Home },
      ...(user ? [{ id: 'dashboard', label: 'Dashboard', icon: BarChart3 }] : []),
      { id: 'report', label: 'Report Issue', icon: MessageSquare },
      { id: 'issues', label: 'View Issues', icon: Eye },
      { id: 'analytics', label: 'Analytics', icon: TrendingUp },
    ];

    if (user?.role === 'government' || user?.role === 'admin') {
      baseItems.push({ id: 'government', label: 'Dashboard', icon: TrendingUp });
    }
    
    if (user?.role === 'admin') {
      baseItems.push({ id: 'admin', label: 'Admin', icon: Settings });
    }

    return baseItems;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Stand with Nepal</h1>
          <p className="text-red-600 font-medium mb-4">नागरिक आवाज मञ्च</p>
          <LoadingSpinner size="lg" />
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gray-50">
        {/* Navigation Header */}
        <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo and Brand */}
            <div className="flex items-center space-x-3">
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900">Stand with Nepal</h1>
                  <p className="text-xs text-red-600 font-medium">नागरिक आवाज मञ्च</p>
                </div>
              </div>
            </div>

            {/* Navigation Items */}
            <div className="hidden md:flex items-center space-x-1">
              {getNavItems().map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentPage(item.id)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      currentPage === item.id
                        ? 'bg-red-50 text-red-700'
                        : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>

            {/* User Section */}
            <div className="flex items-center space-x-3">
              {user && <NotificationSystem user={user} />}
              
              {user ? (
                <div className="flex items-center space-x-3">
                  <div className="relative">
                    <button
                      onClick={() => setShowUserProfile(!showUserProfile)}
                      className="flex items-center space-x-2 px-3 py-2 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                    >
                      <User className="w-4 h-4 text-gray-600" />
                      <span className="text-sm font-medium text-gray-700 capitalize">
                        {user.role}
                      </span>
                    </button>
                    
                    {showUserProfile && (
                      <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-1">
                        <div className="px-4 py-2 border-b border-gray-100">
                          <p className="text-sm font-medium text-gray-900">{user.name}</p>
                          <p className="text-xs text-gray-500">{user.email}</p>
                          {user.isVerified && (
                            <span className="inline-block bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium mt-1">
                              Verified
                            </span>
                          )}
                        </div>
                        <button
                          onClick={() => {
                            setShowUserProfile(false);
                            // Handle profile view
                          }}
                          className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
                        >
                          Profile Settings
                        </button>
                        <button
                          onClick={() => {
                            setShowUserProfile(false);
                            handleLogout();
                          }}
                          className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 flex items-center space-x-2"
                        >
                          <LogOut className="w-4 h-4" />
                          <span>Logout</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setShowAuthModal(true)}
                  className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700 transition-colors"
                >
                  Login / Register
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className="md:hidden border-t border-gray-200">
          <div className="flex overflow-x-auto py-2 px-4 space-x-1">
            {getNavItems().map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentPage(item.id)}
                  className={`flex flex-col items-center space-y-1 px-3 py-2 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                    currentPage === item.id
                      ? 'bg-red-50 text-red-700'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>


        </nav>

        {/* Main Content */}
        <main className="flex-1">
          {renderCurrentPage()}
        </main>

        {/* Authentication Modal */}
        {showAuthModal && (
          <AuthModal
            isOpen={showAuthModal}
            onClose={() => setShowAuthModal(false)}
            onLogin={handleLogin}
          />
        )}
      </div>
    </ErrorBoundary>
  );
}

export default App;