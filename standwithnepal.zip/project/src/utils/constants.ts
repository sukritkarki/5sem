export const NEPAL_PROVINCES = [
  'Province 1',
  'Madhesh Province',
  'Bagmati Province',
  'Gandaki Province',
  'Lumbini Province',
  'Karnali Province',
  'Sudurpashchim Province'
] as const;

export const ISSUE_CATEGORIES = [
  'Road Infrastructure',
  'Electricity',
  'Water Supply',
  'Healthcare',
  'Education',
  'Sanitation',
  'Transportation',
  'Corruption',
  'Environment',
  'Public Safety',
  'Government Services',
  'Other'
] as const;

export const ISSUE_STATUSES = [
  'New',
  'Acknowledged',
  'In Progress',
  'Resolved'
] as const;

export const SEVERITY_LEVELS = [
  'low',
  'medium',
  'high',
  'urgent'
] as const;

export const USER_ROLES = [
  'citizen',
  'government',
  'admin'
] as const;

export const DEPARTMENTS = [
  'Road Department',
  'Electricity Department',
  'Water Department',
  'Health Department',
  'Education Department',
  'Environment Department',
  'Public Safety Department',
  'Administrative Department',
  'Sanitation Department',
  'Transportation Department'
] as const;

export const FILE_UPLOAD_LIMITS = {
  MAX_FILE_SIZE: 10 * 1024 * 1024, // 10MB
  MAX_FILES: 5,
  ACCEPTED_TYPES: ['image/*', 'video/*', '.pdf', '.doc', '.docx']
} as const;

export const PAGINATION = {
  DEFAULT_PAGE_SIZE: 10,
  MAX_PAGE_SIZE: 50
} as const;