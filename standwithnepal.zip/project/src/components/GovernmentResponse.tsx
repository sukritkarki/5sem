import React, { useState } from 'react';
import { MessageSquare, Send, Clock, CheckCircle, AlertTriangle } from 'lucide-react';

interface GovernmentResponseProps {
  issueId: string;
  currentStatus: 'New' | 'Acknowledged' | 'In Progress' | 'Resolved';
  currentResponse?: string;
  assignedDepartment?: string;
  onUpdate: (data: {
    status: string;
    response: string;
    department: string;
  }) => void;
  userRole: 'government' | 'admin';
}

const GovernmentResponse: React.FC<GovernmentResponseProps> = ({
  issueId,
  currentStatus,
  currentResponse = '',
  assignedDepartment = '',
  onUpdate,
  userRole
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    status: currentStatus,
    response: currentResponse,
    department: assignedDepartment
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const departments = [
    'Road Department',
    'Electricity Department',
    'Water Department',
    'Health Department',
    'Education Department',
    'Environment Department',
    'Public Safety Department',
    'Administrative Department',
    'Sanitation Department',
    'Transportation Department'
  ];

  const statusOptions = [
    { value: 'New', label: 'New', color: 'text-yellow-600', icon: AlertTriangle },
    { value: 'Acknowledged', label: 'Acknowledged', color: 'text-blue-600', icon: MessageSquare },
    { value: 'In Progress', label: 'In Progress', color: 'text-orange-600', icon: Clock },
    { value: 'Resolved', label: 'Resolved', color: 'text-green-600', icon: CheckCircle }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      onUpdate(formData);
      setIsEditing(false);
    } catch (error) {
      console.error('Error updating issue:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancel = () => {
    setFormData({
      status: currentStatus,
      response: currentResponse,
      department: assignedDepartment
    });
    setIsEditing(false);
  };

  const getStatusIcon = (status: string) => {
    const statusOption = statusOptions.find(opt => opt.value === status);
    if (statusOption) {
      const Icon = statusOption.icon;
      return <Icon className={`w-4 h-4 ${statusOption.color}`} />;
    }
    return <MessageSquare className="w-4 h-4 text-gray-600" />;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'New':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Acknowledged':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'In Progress':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Resolved':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
          <MessageSquare className="w-5 h-5 text-blue-600" />
          <span>Government Response</span>
        </h3>
        
        {!isEditing && (userRole === 'government' || userRole === 'admin') && (
          <button
            onClick={() => setIsEditing(true)}
            className="text-blue-600 hover:text-blue-700 font-medium text-sm"
          >
            Update Response
          </button>
        )}
      </div>

      {/* Current Status Display */}
      <div className="mb-4">
        <div className="flex items-center space-x-3">
          <span className={`inline-flex items-center space-x-2 px-3 py-2 rounded-lg border ${getStatusColor(currentStatus)}`}>
            {getStatusIcon(currentStatus)}
            <span className="font-medium">{currentStatus}</span>
          </span>
          
          {assignedDepartment && (
            <span className="bg-blue-100 text-blue-800 px-3 py-2 rounded-lg text-sm font-medium">
              {assignedDepartment}
            </span>
          )}
        </div>
      </div>

      {/* Response Content */}
      {!isEditing ? (
        <div>
          {currentResponse ? (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-blue-900">{currentResponse}</p>
            </div>
          ) : (
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-center">
              <MessageSquare className="w-8 h-8 text-gray-400 mx-auto mb-2" />
              <p className="text-gray-600">No government response yet</p>
              <p className="text-sm text-gray-500 mt-1">
                Government officials will provide updates here
              </p>
            </div>
          )}
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Status *
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value }))}
                required
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                {statusOptions.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Assign Department
              </label>
              <select
                value={formData.department}
                onChange={(e) => setFormData(prev => ({ ...prev, department: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">Select Department</option>
                {departments.map((dept) => (
                  <option key={dept} value={dept}>
                    {dept}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Response Message *
            </label>
            <textarea
              value={formData.response}
              onChange={(e) => setFormData(prev => ({ ...prev, response: e.target.value }))}
              required
              rows={4}
              placeholder="Provide an update to citizens about this issue..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>

          <div className="flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={handleCancel}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
              <span>{isSubmitting ? 'Updating...' : 'Update Response'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Response Guidelines */}
      {isEditing && (
        <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
          <h4 className="font-medium text-yellow-900 mb-2">Response Guidelines:</h4>
          <ul className="text-sm text-yellow-800 space-y-1">
            <li>• Be clear and specific about actions being taken</li>
            <li>• Provide realistic timelines for resolution</li>
            <li>• Include contact information if citizens need follow-up</li>
            <li>• Update status regularly to keep citizens informed</li>
          </ul>
        </div>
      )}
    </div>
  );
};

export default GovernmentResponse;