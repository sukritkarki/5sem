import React, { useState, useRef } from 'react';
import { Upload, X, Image, Video, File, Camera } from 'lucide-react';
import { FILE_UPLOAD_LIMITS } from '../utils/constants';
import { validateFile, formatFileSize } from '../utils/helpers';

interface MediaFile {
  id: string;
  file: File;
  type: 'image' | 'video' | 'document';
  preview?: string;
  uploadProgress?: number;
}

interface MediaUploadProps {
  onFilesChange: (files: File[]) => void;
  maxFiles?: number;
  maxFileSize?: number;
  acceptedTypes?: string[];
  showPreview?: boolean;
}

const MediaUpload: React.FC<MediaUploadProps> = ({
  onFilesChange,
  maxFiles = FILE_UPLOAD_LIMITS.MAX_FILES,
  maxFileSize = FILE_UPLOAD_LIMITS.MAX_FILE_SIZE / (1024 * 1024), // Convert to MB
  acceptedTypes = FILE_UPLOAD_LIMITS.ACCEPTED_TYPES,
  showPreview = true
}) => {
  const [mediaFiles, setMediaFiles] = useState<MediaFile[]>([]);
  const [dragActive, setDragActive] = useState(false);
  const [uploadError, setUploadError] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getFileType = (file: File): 'image' | 'video' | 'document' => {
    if (file.type.startsWith('image/')) return 'image';
    if (file.type.startsWith('video/')) return 'video';
    return 'document';
  };

  const createFilePreview = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => resolve(e.target?.result as string);
        reader.readAsDataURL(file);
      } else {
        resolve('');
      }
    });
  };

  const validateFile = (file: File): string | null => {
    return validateFile(file, maxFileSize * 1024 * 1024, acceptedTypes);
  };

  const handleFiles = async (files: FileList) => {
    setUploadError('');
    const newFiles: MediaFile[] = [];

    // Check total file count
    if (mediaFiles.length + files.length > maxFiles) {
      setUploadError(`Maximum ${maxFiles} files allowed`);
      return;
    }

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const error = validateFile(file);
      
      if (error) {
        setUploadError(error);
        continue;
      }

      const preview = await createFilePreview(file);
      const mediaFile: MediaFile = {
        id: Math.random().toString(36).substr(2, 9),
        file,
        type: getFileType(file),
        preview,
        uploadProgress: 0
      };

      newFiles.push(mediaFile);
    }

    const updatedFiles = [...mediaFiles, ...newFiles];
    setMediaFiles(updatedFiles);
    onFilesChange(updatedFiles.map(mf => mf.file));
  };

  const removeFile = (fileId: string) => {
    const updatedFiles = mediaFiles.filter(file => file.id !== fileId);
    setMediaFiles(updatedFiles);
    onFilesChange(updatedFiles.map(mf => mf.file));
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFiles(e.dataTransfer.files);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFiles(e.target.files);
    }
  };

  const openFileDialog = () => {
    fileInputRef.current?.click();
  };

  const getFileIcon = (type: 'image' | 'video' | 'document') => {
    switch (type) {
      case 'image':
        return <Image className="w-6 h-6" />;
      case 'video':
        return <Video className="w-6 h-6" />;
      case 'document':
        return <File className="w-6 h-6" />;
    }
  };


  return (
    <div className="space-y-4">
      {/* Upload Area */}
      <div
        className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors cursor-pointer ${
          dragActive
            ? 'border-red-400 bg-red-50'
            : 'border-gray-300 hover:border-gray-400 hover:bg-gray-50'
        }`}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={openFileDialog}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept={acceptedTypes.join(',')}
          onChange={handleFileInput}
          className="hidden"
        />
        
        <div className="space-y-3">
          <div className="flex justify-center">
            <div className="p-3 bg-gray-100 rounded-full">
              <Upload className="w-8 h-8 text-gray-600" />
            </div>
          </div>
          
          <div>
            <p className="text-lg font-medium text-gray-900">
              Upload Photos or Videos
            </p>
            <p className="text-sm text-gray-600 mt-1">
              Click to browse or drag and drop files here
            </p>
          </div>
          
          <div className="text-xs text-gray-500">
            <p>Supported formats: Images, Videos, PDF, DOC</p>
            <p>Maximum file size: {maxFileSize}MB | Maximum files: {maxFiles}</p>
          </div>
        </div>
      </div>

      {/* Error Message */}
      {uploadError && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3">
          <p className="text-sm text-red-800">{uploadError}</p>
        </div>
      )}

      {/* File Previews */}
      {showPreview && mediaFiles.length > 0 && (
        <div className="space-y-3">
          <h4 className="font-medium text-gray-900">Uploaded Files ({mediaFiles.length}/{maxFiles})</h4>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {mediaFiles.map((mediaFile) => (
              <div key={mediaFile.id} className="relative bg-white border border-gray-200 rounded-lg p-3">
                {/* Remove Button */}
                <button
                  onClick={() => removeFile(mediaFile.id)}
                  className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors z-10"
                >
                  <X className="w-4 h-4" />
                </button>

                {/* File Preview */}
                <div className="space-y-2">
                  {mediaFile.type === 'image' && mediaFile.preview ? (
                    <div className="aspect-video bg-gray-100 rounded-lg overflow-hidden">
                      <img
                        src={mediaFile.preview}
                        alt="Preview"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : (
                    <div className="aspect-video bg-gray-100 rounded-lg flex items-center justify-center">
                      <div className="text-center">
                        <div className="flex justify-center mb-2 text-gray-400">
                          {getFileIcon(mediaFile.type)}
                        </div>
                        <p className="text-xs text-gray-600 capitalize">{mediaFile.type}</p>
                      </div>
                    </div>
                  )}

                  {/* File Info */}
                  <div className="space-y-1">
                    <p className="text-sm font-medium text-gray-900 truncate">
                      {mediaFile.file.name}
                    </p>
                    <p className="text-xs text-gray-500">
                      {formatFileSize(mediaFile.file.size)}
                    </p>
                  </div>

                  {/* Upload Progress */}
                  {mediaFile.uploadProgress !== undefined && mediaFile.uploadProgress < 100 && (
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-red-600 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${mediaFile.uploadProgress}%` }}
                      ></div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="flex items-center space-x-3 pt-2">
        <button
          onClick={openFileDialog}
          className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
        >
          <Camera className="w-4 h-4" />
          <span>Add Photos</span>
        </button>
        
        <button
          onClick={openFileDialog}
          className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors"
        >
          <Video className="w-4 h-4" />
          <span>Add Videos</span>
        </button>
      </div>
    </div>
  );
};

export default MediaUpload;