import React, { useState } from 'react';
import { 
  MapPin, 
  Calendar, 
  User, 
  ThumbsUp, 
  MessageSquare, 
  Share2, 
  Flag,
  X,
  Clock
} from 'lucide-react';
import StatusTracker from './StatusTracker';
import GovernmentResponse from './GovernmentResponse';
import CitizenFeedback from './CitizenFeedback';

interface Issue {
  id: string;
  title: string;
  description: string;
  category: string;
  location: {
    province: string;
    district: string;
    municipality: string;
    ward: string;
  };
  status: 'New' | 'Acknowledged' | 'In Progress' | 'Resolved';
  severity: 'low' | 'medium' | 'high' | 'urgent';
  upvotes: number;
  comments: number;
  reportedBy: string;
  isAnonymous: boolean;
  createdAt: string;
  updatedAt: string;
  images?: string[];
  governmentResponse?: string;
  assignedDepartment?: string;
  statusHistory?: Array<{
    id: string;
    status: 'New' | 'Acknowledged' | 'In Progress' | 'Resolved';
    timestamp: string;
    updatedBy: string;
    message?: string;
    department?: string;
  }>;
}

interface Comment {
  id: string;
  author: string;
  content: string;
  createdAt: string;
  isOfficial: boolean;
}

interface IssueDetailsProps {
  issue: Issue;
  isOpen: boolean;
  onClose: () => void;
  onUpvote: (issueId: string) => void;
  onComment: (issueId: string, comment: string) => void;
  userRole?: 'citizen' | 'government' | 'admin';
}

const IssueDetails: React.FC<IssueDetailsProps> = ({
  issue,
  isOpen,
  onClose,
  onUpvote,
  onComment,
  userRole = 'citizen'
}) => {
  const [newComment, setNewComment] = useState('');
  const [isUpvoted, setIsUpvoted] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);

  const handleGovernmentUpdate = (data: { status: string; response: string; department: string }) => {
    console.log('Government update:', data);
    // In real app, this would update the issue via API
  };

  const handleCitizenFeedback = (feedback: { rating: number; satisfaction: string; comment: string }) => {
    console.log('Citizen feedback:', feedback);
    // In real app, this would submit feedback via API
  };

  // Mock status history
  const statusHistory = issue.statusHistory || [
    {
      id: '1',
      status: 'Acknowledged' as const,
      timestamp: '2024-01-16T09:00:00Z',
      updatedBy: 'Kathmandu Municipality',
      message: 'Issue has been received and is under review.',
      department: 'Road Department'
    },
    {
      id: '2',
      status: 'In Progress' as const,
      timestamp: '2024-01-16T14:30:00Z',
      updatedBy: 'Road Department',
      message: 'Repair work has begun. Expected completion within 3 days.',
      department: 'Road Department'
    }
  ];

  // Mock comments data
  const comments: Comment[] = [
    {
      id: '1',
      author: 'Ram Sharma',
      content: 'This is a serious issue. I have also noticed this problem in our area.',
      createdAt: '2024-01-16T10:30:00Z',
      isOfficial: false
    },
    {
      id: '2',
      author: 'Kathmandu Municipality',
      content: 'Thank you for reporting this issue. We have forwarded it to the concerned department for immediate action.',
      createdAt: '2024-01-16T14:20:00Z',
      isOfficial: true
    }
  ];

  const handleUpvote = () => {
    setIsUpvoted(!isUpvoted);
    onUpvote(issue.id);
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newComment.trim()) {
      onComment(issue.id, newComment);
      setNewComment('');
    }
  };


  const getStatusColor = (status: string) => {
    switch (status) {
      case 'New':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Acknowledged':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'In Progress':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Resolved':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low':
        return 'bg-green-100 text-green-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'high':
        return 'bg-orange-100 text-orange-800';
      case 'urgent':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center space-x-3">
            <h2 className="text-xl font-semibold text-gray-900">{issue.title}</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex flex-col lg:flex-row max-h-[calc(90vh-80px)]">
          {/* Main Content */}
          <div className="flex-1 p-6 overflow-y-auto space-y-6">
            {/* Issue Info */}
            <div>
              <div className="flex flex-wrap items-center gap-2 mb-4">
                <span className="bg-gray-100 px-3 py-1 rounded-full text-sm font-medium text-gray-700">
                  {issue.category}
                </span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getStatusColor(issue.status)}`}>
                  {issue.status}
                </span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getSeverityColor(issue.severity)}`}>
                  {issue.severity.charAt(0).toUpperCase() + issue.severity.slice(1)} Priority
                </span>
                {issue.assignedDepartment && (
                  <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                    {issue.assignedDepartment}
                  </span>
                )}
              </div>

              <p className="text-gray-700 mb-4 leading-relaxed">{issue.description}</p>

              {/* Location and Date Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div className="flex items-center space-x-2 text-gray-600">
                  <MapPin className="w-4 h-4" />
                  <span className="text-sm">
                    {issue.location.municipality}, Ward {issue.location.ward}, {issue.location.district}
                  </span>
                </div>
                <div className="flex items-center space-x-2 text-gray-600">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm">Reported on {formatDate(issue.createdAt)}</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-600">
                  <User className="w-4 h-4" />
                  <span className="text-sm">
                    By: {issue.isAnonymous ? 'Anonymous Citizen' : issue.reportedBy}
                  </span>
                </div>
                {issue.updatedAt !== issue.createdAt && (
                  <div className="flex items-center space-x-2 text-gray-600">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">Last updated {formatDate(issue.updatedAt)}</span>
                  </div>
                )}
              </div>

              {/* Government Response */}
              {issue.governmentResponse && (
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                  <h4 className="font-medium text-blue-900 mb-2 flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4" />
                    <span>Official Response</span>
                  </h4>
                  <p className="text-blue-800">{issue.governmentResponse}</p>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center space-x-4">
                <button
                  onClick={handleUpvote}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg border transition-colors ${
                    isUpvoted
                      ? 'bg-red-50 border-red-200 text-red-700'
                      : 'bg-white border-gray-300 text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <ThumbsUp className={`w-4 h-4 ${isUpvoted ? 'fill-current' : ''}`} />
                  <span>{issue.upvotes + (isUpvoted ? 1 : 0)}</span>
                </button>

                <button className="flex items-center space-x-2 px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors">
                  <Share2 className="w-4 h-4" />
                  <span>Share</span>
                </button>

                <button
                  onClick={() => setShowReportModal(true)}
                  className="flex items-center space-x-2 px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  <Flag className="w-4 h-4" />
                  <span>Report</span>
                </button>
              </div>
            </div>

            {/* Status Tracker */}
            <StatusTracker
              currentStatus={issue.status}
              statusHistory={statusHistory}
              createdAt={issue.createdAt}
              createdBy={issue.reportedBy}
              isAnonymous={issue.isAnonymous}
            />

            {/* Government Response Section */}
            {(userRole === 'government' || userRole === 'admin' || issue.governmentResponse) && (
              <GovernmentResponse
                issueId={issue.id}
                currentStatus={issue.status}
                currentResponse={issue.governmentResponse}
                assignedDepartment={issue.assignedDepartment}
                onUpdate={handleGovernmentUpdate}
                userRole={userRole as 'government' | 'admin'}
              />
            )}

            {/* Citizen Feedback Section */}
            {userRole === 'citizen' && (issue.status === 'In Progress' || issue.status === 'Resolved') && (
              <CitizenFeedback
                issueId={issue.id}
                issueStatus={issue.status}
                onFeedbackSubmit={handleCitizenFeedback}
              />
            )}
            {/* Comments Section */}
            <div className="border-t border-gray-200 pt-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
                <MessageSquare className="w-5 h-5" />
                <span>Comments ({comments.length})</span>
              </h3>

              {/* Add Comment Form */}
              <form onSubmit={handleCommentSubmit} className="mb-6">
                <textarea
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Add your comment..."
                  rows={3}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 resize-none"
                />
                <div className="flex justify-end mt-2">
                  <button
                    type="submit"
                    disabled={!newComment.trim()}
                    className="bg-red-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Post Comment
                  </button>
                </div>
              </form>

              {/* Comments List */}
              <div className="space-y-4">
                {comments.map((comment) => (
                  <div key={comment.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <span className={`font-medium ${comment.isOfficial ? 'text-blue-600' : 'text-gray-900'}`}>
                          {comment.author}
                        </span>
                        {comment.isOfficial && (
                          <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                            Official
                          </span>
                        )}
                      </div>
                      <span className="text-sm text-gray-500">
                        {formatDate(comment.createdAt)}
                      </span>
                    </div>
                    <p className="text-gray-700">{comment.content}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar - Issue Timeline */}
          <div className="w-full lg:w-80 bg-gray-50 p-6 border-l border-gray-200 overflow-y-auto space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Issue Information</h3>
              <div className="space-y-3">
                <div>
                  <span className="text-sm font-medium text-gray-600">Category:</span>
                  <p className="text-sm text-gray-900">{issue.category}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600">Location:</span>
                  <p className="text-sm text-gray-900">
                    {issue.location.municipality}, Ward {issue.location.ward}
                  </p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600">Reported By:</span>
                  <p className="text-sm text-gray-900">
                    {issue.isAnonymous ? 'Anonymous Citizen' : issue.reportedBy}
                  </p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-600">Severity:</span>
                  <p className="text-sm text-gray-900 capitalize">{issue.severity}</p>
                </div>
              </div>
            </div>

            {/* Issue Statistics */}
            <div className="pt-6 border-t border-gray-200">
              <h4 className="font-medium text-gray-900 mb-3">Issue Statistics</h4>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Total Upvotes</span>
                  <span className="font-medium text-gray-900">{issue.upvotes}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Comments</span>
                  <span className="font-medium text-gray-900">{comments.length}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Days Open</span>
                  <span className="font-medium text-gray-900">
                    {Math.floor((new Date().getTime() - new Date(issue.createdAt).getTime()) / (1000 * 60 * 60 * 24))}
                  </span>
                </div>
                {issue.status === 'Resolved' && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Resolution Time</span>
                    <span className="font-medium text-green-600">
                      {Math.floor((new Date(issue.updatedAt).getTime() - new Date(issue.createdAt).getTime()) / (1000 * 60 * 60 * 24))} days
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Issue Actions for Government Users */}
            {(userRole === 'government' || userRole === 'admin') && (
              <div className="pt-6 border-t border-gray-200">
                <h4 className="font-medium text-gray-900 mb-3">Quick Actions</h4>
                <div className="space-y-2">
                  <button className="w-full text-left px-3 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                    Assign to Department
                  </button>
                  <button className="w-full text-left px-3 py-2 text-sm text-orange-600 hover:bg-orange-50 rounded-lg transition-colors">
                    Request More Information
                  </button>
                  <button className="w-full text-left px-3 py-2 text-sm text-green-600 hover:bg-green-50 rounded-lg transition-colors">
                    Mark as Priority
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Report Modal */}
      {showReportModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-60">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Report Issue</h3>
            <p className="text-gray-600 mb-4">
              Why are you reporting this issue? This will help our moderators review the content.
            </p>
            <div className="space-y-2 mb-4">
              {['Spam', 'Inappropriate Content', 'False Information', 'Duplicate', 'Other'].map((reason) => (
                <label key={reason} className="flex items-center space-x-2">
                  <input type="radio" name="reportReason" value={reason} className="text-red-600" />
                  <span className="text-sm text-gray-700">{reason}</span>
                </label>
              ))}
            </div>
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowReportModal(false)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowReportModal(false);
                  // Handle report submission
                }}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                Submit Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default IssueDetails;