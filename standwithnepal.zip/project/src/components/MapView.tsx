import React, { useState, useEffect } from 'react';
import { MapPin, Filter, Eye, MessageSquare, Calendar } from 'lucide-react';

interface Issue {
  id: string;
  title: string;
  description: string;
  category: string;
  location: {
    province: string;
    district: string;
    municipality: string;
    ward: string;
    coordinates: {
      lat: number;
      lng: number;
    };
  };
  status: 'New' | 'Acknowledged' | 'In Progress' | 'Resolved';
  severity: 'low' | 'medium' | 'high' | 'urgent';
  upvotes: number;
  comments: number;
  createdAt: string;
}

interface MapViewProps {
  issues: Issue[];
  onIssueSelect: (issue: Issue) => void;
  selectedCategory?: string;
  selectedStatus?: string;
}

const MapView: React.FC<MapViewProps> = ({ 
  issues, 
  onIssueSelect, 
  selectedCategory, 
  selectedStatus 
}) => {
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);
  const [mapCenter, setMapCenter] = useState({ lat: 27.7172, lng: 85.3240 }); // Kathmandu center

  const filteredIssues = issues.filter(issue => {
    const matchesCategory = !selectedCategory || issue.category === selectedCategory;
    const matchesStatus = !selectedStatus || issue.status === selectedStatus;
    return matchesCategory && matchesStatus;
  });

  const getMarkerColor = (status: string) => {
    switch (status) {
      case 'New': return '#EAB308'; // yellow
      case 'Acknowledged': return '#3B82F6'; // blue
      case 'In Progress': return '#F97316'; // orange
      case 'Resolved': return '#10B981'; // green
      default: return '#6B7280'; // gray
    }
  };

  const getSeveritySize = (severity: string) => {
    switch (severity) {
      case 'urgent': return 16;
      case 'high': return 14;
      case 'medium': return 12;
      case 'low': return 10;
      default: return 12;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="relative w-full h-96 bg-gray-100 rounded-lg overflow-hidden">
      {/* Map Container - In a real implementation, this would use Google Maps or Leaflet */}
      <div className="absolute inset-0 bg-gradient-to-br from-green-100 to-blue-100">
        {/* Simulated map background */}
        <div className="absolute inset-0 opacity-20">
          <svg width="100%" height="100%" viewBox="0 0 400 300">
            {/* Simulated map paths */}
            <path d="M50 50 Q200 100 350 50 T350 250 Q200 200 50 250 Z" 
                  fill="none" stroke="#10B981" strokeWidth="2" opacity="0.3"/>
            <path d="M100 80 L300 80 L300 220 L100 220 Z" 
                  fill="none" stroke="#3B82F6" strokeWidth="1" opacity="0.2"/>
          </svg>
        </div>

        {/* Issue Markers */}
        {filteredIssues.map((issue, index) => (
          <div
            key={issue.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all duration-200 hover:scale-110"
            style={{
              left: `${20 + (index % 8) * 10}%`,
              top: `${20 + Math.floor(index / 8) * 15}%`,
            }}
            onClick={() => {
              setSelectedIssue(issue);
              onIssueSelect(issue);
            }}
          >
            <div
              className="rounded-full border-2 border-white shadow-lg flex items-center justify-center"
              style={{
                backgroundColor: getMarkerColor(issue.status),
                width: getSeveritySize(issue.severity),
                height: getSeveritySize(issue.severity),
              }}
            >
              <MapPin className="w-3 h-3 text-white" />
            </div>
            
            {/* Tooltip on hover */}
            <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 hover:opacity-100 transition-opacity duration-200 pointer-events-none">
              <div className="bg-gray-900 text-white text-xs rounded-lg px-2 py-1 whitespace-nowrap">
                {issue.title}
              </div>
              <div className="absolute top-full left-1/2 transform -translate-x-1/2 border-4 border-transparent border-t-gray-900"></div>
            </div>
          </div>
        ))}

        {/* Legend */}
        <div className="absolute bottom-4 left-4 bg-white rounded-lg shadow-lg p-3">
          <h4 className="text-sm font-medium text-gray-900 mb-2">Status Legend</h4>
          <div className="space-y-1">
            {[
              { status: 'New', color: '#EAB308', label: 'New' },
              { status: 'Acknowledged', color: '#3B82F6', label: 'Acknowledged' },
              { status: 'In Progress', color: '#F97316', label: 'In Progress' },
              { status: 'Resolved', color: '#10B981', label: 'Resolved' }
            ].map((item) => (
              <div key={item.status} className="flex items-center space-x-2">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: item.color }}
                ></div>
                <span className="text-xs text-gray-600">{item.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Issue Details Panel */}
        {selectedIssue && (
          <div className="absolute top-4 right-4 bg-white rounded-lg shadow-lg p-4 w-80 max-h-80 overflow-y-auto">
            <div className="flex items-start justify-between mb-3">
              <h3 className="font-semibold text-gray-900 text-sm">{selectedIssue.title}</h3>
              <button
                onClick={() => setSelectedIssue(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                ×
              </button>
            </div>
            
            <p className="text-gray-600 text-sm mb-3">{selectedIssue.description}</p>
            
            <div className="flex flex-wrap gap-1 mb-3">
              <span className="bg-gray-100 px-2 py-1 rounded-full text-xs font-medium text-gray-700">
                {selectedIssue.category}
              </span>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                selectedIssue.status === 'New' ? 'bg-yellow-100 text-yellow-800' :
                selectedIssue.status === 'Acknowledged' ? 'bg-blue-100 text-blue-800' :
                selectedIssue.status === 'In Progress' ? 'bg-orange-100 text-orange-800' :
                'bg-green-100 text-green-800'
              }`}>
                {selectedIssue.status}
              </span>
              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                selectedIssue.severity === 'low' ? 'bg-green-100 text-green-800' :
                selectedIssue.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                selectedIssue.severity === 'high' ? 'bg-orange-100 text-orange-800' :
                'bg-red-100 text-red-800'
              }`}>
                {selectedIssue.severity.charAt(0).toUpperCase() + selectedIssue.severity.slice(1)}
              </span>
            </div>

            <div className="flex items-center space-x-4 text-xs text-gray-500 mb-3">
              <span className="flex items-center space-x-1">
                <MapPin className="w-3 h-3" />
                <span>Ward {selectedIssue.location.ward}</span>
              </span>
              <span className="flex items-center space-x-1">
                <Calendar className="w-3 h-3" />
                <span>{formatDate(selectedIssue.createdAt)}</span>
              </span>
            </div>

            <div className="flex items-center space-x-4 text-xs text-gray-500">
              <span className="flex items-center space-x-1">
                <Eye className="w-3 h-3" />
                <span>{selectedIssue.upvotes} upvotes</span>
              </span>
              <span className="flex items-center space-x-1">
                <MessageSquare className="w-3 h-3" />
                <span>{selectedIssue.comments} comments</span>
              </span>
            </div>

            <button
              onClick={() => onIssueSelect(selectedIssue)}
              className="w-full mt-3 bg-red-600 text-white py-2 px-3 rounded-lg text-sm font-medium hover:bg-red-700 transition-colors"
            >
              View Full Details
            </button>
          </div>
        )}

        {/* Map Controls */}
        <div className="absolute top-4 left-4 bg-white rounded-lg shadow-lg">
          <button className="p-2 hover:bg-gray-50 border-b border-gray-200">
            <span className="text-lg font-bold">+</span>
          </button>
          <button className="p-2 hover:bg-gray-50">
            <span className="text-lg font-bold">−</span>
          </button>
        </div>
      </div>

      {/* No issues message */}
      {filteredIssues.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-2" />
            <p className="text-gray-600">No issues found for the selected filters</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default MapView;