import React, { useState } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  AlertCircle, 
  CheckCircle, 
  Clock,
  MapPin,
  Calendar,
  Filter
} from 'lucide-react';
import QuickStats from './QuickStats';
import TrendingIssues from './TrendingIssues';
import IssueCard from './IssueCard';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'citizen' | 'government' | 'admin';
  jurisdiction?: {
    province: string;
    district: string;
    municipality: string;
    ward: string;
  };
  isVerified: boolean;
}

interface DashboardProps {
  user: User;
}

const Dashboard: React.FC<DashboardProps> = ({ user }) => {
  const [selectedTimeframe, setSelectedTimeframe] = useState('week');
  const [selectedCategory, setSelectedCategory] = useState('all');

  // Mock data based on user role and jurisdiction
  const getDashboardData = () => {
    if (user.role === 'citizen') {
      return {
        stats: [
          {
            label: 'My Issues',
            value: 5,
            change: { value: 2, type: 'increase' as const, period: 'this month' },
            icon: AlertCircle,
            color: 'text-blue-600',
            bgColor: 'bg-blue-50'
          },
          {
            label: 'Resolved',
            value: 3,
            change: { value: 1, type: 'increase' as const, period: 'this month' },
            icon: CheckCircle,
            color: 'text-green-600',
            bgColor: 'bg-green-50'
          },
          {
            label: 'In Progress',
            value: 2,
            change: { value: 0, type: 'neutral' as const, period: 'this month' },
            icon: Clock,
            color: 'text-orange-600',
            bgColor: 'bg-orange-50'
          },
          {
            label: 'Community Impact',
            value: 156,
            change: { value: 23, type: 'increase' as const, period: 'this month' },
            icon: Users,
            color: 'text-purple-600',
            bgColor: 'bg-purple-50'
          }
        ],
        recentActivity: [
          'Your water shortage issue was marked as resolved',
          'New issue reported in your area: Road maintenance needed',
          'Government responded to your streetlight complaint',
          'Your issue received 5 new upvotes'
        ]
      };
    } else if (user.role === 'government') {
      return {
        stats: [
          {
            label: 'Pending Issues',
            value: 12,
            change: { value: -3, type: 'decrease' as const, period: 'this week' },
            icon: AlertCircle,
            color: 'text-yellow-600',
            bgColor: 'bg-yellow-50'
          },
          {
            label: 'Resolved This Month',
            value: 28,
            change: { value: 15, type: 'increase' as const, period: 'last month' },
            icon: CheckCircle,
            color: 'text-green-600',
            bgColor: 'bg-green-50'
          },
          {
            label: 'Avg Response Time',
            value: '2.3 days',
            change: { value: -12, type: 'decrease' as const, period: 'this month' },
            icon: Clock,
            color: 'text-blue-600',
            bgColor: 'bg-blue-50'
          },
          {
            label: 'Citizen Satisfaction',
            value: 87.5,
            change: { value: 5, type: 'increase' as const, period: 'this month' },
            icon: TrendingUp,
            color: 'text-purple-600',
            bgColor: 'bg-purple-50'
          }
        ],
        recentActivity: [
          'New urgent issue reported: Water pipe burst in Ward 5',
          'Citizen provided positive feedback on road repair',
          'Issue escalated: Electricity outage affecting 200+ homes',
          'Department assigned: Sanitation issue in Ward 12'
        ]
      };
    } else {
      return {
        stats: [
          {
            label: 'Total Issues',
            value: 2847,
            change: { value: 12, type: 'increase' as const, period: 'this month' },
            icon: BarChart3,
            color: 'text-blue-600',
            bgColor: 'bg-blue-50'
          },
          {
            label: 'Active Users',
            value: 12450,
            change: { value: 8, type: 'increase' as const, period: 'this month' },
            icon: Users,
            color: 'text-green-600',
            bgColor: 'bg-green-50'
          },
          {
            label: 'Resolution Rate',
            value: 67.5,
            change: { value: 5, type: 'increase' as const, period: 'this month' },
            icon: CheckCircle,
            color: 'text-purple-600',
            bgColor: 'bg-purple-50'
          },
          {
            label: 'Avg Resolution Time',
            value: '12.5 days',
            change: { value: -8, type: 'decrease' as const, period: 'this month' },
            icon: Clock,
            color: 'text-orange-600',
            bgColor: 'bg-orange-50'
          }
        ],
        recentActivity: [
          'New government official verified: Lalitpur Ward 8',
          'Content flagged for review: Inappropriate language',
          'System maintenance completed successfully',
          'Monthly analytics report generated'
        ]
      };
    }
  };

  const { stats, recentActivity } = getDashboardData();

  // Mock recent issues for the user's context
  const recentIssues = [
    {
      id: '1',
      title: user.role === 'citizen' ? 'My reported streetlight issue' : 'Streetlight repair needed',
      description: 'Broken streetlight making area unsafe at night',
      category: 'Electricity',
      location: {
        province: user.jurisdiction?.province || 'Bagmati Province',
        district: user.jurisdiction?.district || 'Kathmandu',
        municipality: user.jurisdiction?.municipality || 'Kathmandu Metropolitan City',
        ward: user.jurisdiction?.ward || '1'
      },
      status: 'In Progress' as const,
      severity: 'high' as const,
      upvotes: 23,
      comments: 5,
      reportedBy: user.role === 'citizen' ? user.name : 'Sita Sharma',
      isAnonymous: false,
      createdAt: '2024-01-15T10:30:00Z'
    },
    {
      id: '2',
      title: user.role === 'citizen' ? 'Water shortage in my area' : 'Water supply disruption',
      description: 'No water supply for 3 days in residential area',
      category: 'Water Supply',
      location: {
        province: user.jurisdiction?.province || 'Bagmati Province',
        district: user.jurisdiction?.district || 'Kathmandu',
        municipality: user.jurisdiction?.municipality || 'Kathmandu Metropolitan City',
        ward: user.jurisdiction?.ward || '12'
      },
      status: 'Acknowledged' as const,
      severity: 'urgent' as const,
      upvotes: 45,
      comments: 12,
      reportedBy: 'Anonymous',
      isAnonymous: true,
      createdAt: '2024-01-14T08:15:00Z'
    }
  ];

  const handleIssueView = (issue: any) => {
    console.log('Viewing issue:', issue);
  };

  const handleUpvote = (issueId: string) => {
    console.log('Upvoting issue:', issueId);
  };

  const getDashboardTitle = () => {
    switch (user.role) {
      case 'citizen':
        return 'My Dashboard';
      case 'government':
        return `${user.jurisdiction?.municipality} Dashboard`;
      case 'admin':
        return 'System Dashboard';
      default:
        return 'Dashboard';
    }
  };

  const getDashboardDescription = () => {
    switch (user.role) {
      case 'citizen':
        return 'Track your reported issues and community activity';
      case 'government':
        return `Manage issues in ${user.jurisdiction?.municipality}, Ward ${user.jurisdiction?.ward}`;
      case 'admin':
        return 'Platform overview and system management';
      default:
        return 'Platform overview';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">{getDashboardTitle()}</h1>
        <p className="text-gray-600">{getDashboardDescription()}</p>
      </div>

      {/* Quick Stats */}
      <div className="mb-8">
        <QuickStats 
          stats={stats}
          title={`${user.role === 'citizen' ? 'My' : user.role === 'government' ? 'Jurisdiction' : 'Platform'} Overview`}
          showTrends={true}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-8">
          {/* Recent Issues */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">
                  {user.role === 'citizen' ? 'My Recent Issues' : 
                   user.role === 'government' ? 'Recent Issues in Your Area' : 
                   'Recent Platform Issues'}
                </h3>
                <div className="flex items-center space-x-2">
                  <select
                    value={selectedCategory}
                    onChange={(e) => setSelectedCategory(e.target.value)}
                    className="text-sm border border-gray-300 rounded-lg px-3 py-1 focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  >
                    <option value="all">All Categories</option>
                    <option value="Road Infrastructure">Road</option>
                    <option value="Water Supply">Water</option>
                    <option value="Electricity">Electricity</option>
                    <option value="Healthcare">Healthcare</option>
                  </select>
                </div>
              </div>
            </div>
            
            <div className="divide-y divide-gray-200">
              {recentIssues.map((issue) => (
                <div key={issue.id} className="p-4">
                  <IssueCard
                    issue={issue}
                    onView={handleIssueView}
                    onUpvote={handleUpvote}
                    showLocation={user.role !== 'citizen'}
                    compact={true}
                  />
                </div>
              ))}
            </div>
            
            <div className="p-4 bg-gray-50 text-center border-t border-gray-200">
              <button className="text-red-600 hover:text-red-700 font-medium">
                View All Issues
              </button>
            </div>
          </div>

          {/* Trending Issues */}
          <TrendingIssues 
            timeframe={selectedTimeframe as any}
            limit={5}
            showFilters={false}
          />
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Recent Activity */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h3>
            <div className="space-y-3">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-red-500 rounded-full mt-2 flex-shrink-0"></div>
                  <p className="text-sm text-gray-700">{activity}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
            <div className="space-y-2">
              {user.role === 'citizen' && (
                <>
                  <button className="w-full text-left px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                    Report New Issue
                  </button>
                  <button className="w-full text-left px-3 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                    View My Issues
                  </button>
                  <button className="w-full text-left px-3 py-2 text-sm text-green-600 hover:bg-green-50 rounded-lg transition-colors">
                    Browse Community Issues
                  </button>
                </>
              )}
              
              {user.role === 'government' && (
                <>
                  <button className="w-full text-left px-3 py-2 text-sm text-orange-600 hover:bg-orange-50 rounded-lg transition-colors">
                    Review Pending Issues
                  </button>
                  <button className="w-full text-left px-3 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                    Update Issue Status
                  </button>
                  <button className="w-full text-left px-3 py-2 text-sm text-green-600 hover:bg-green-50 rounded-lg transition-colors">
                    View Analytics
                  </button>
                </>
              )}
              
              {user.role === 'admin' && (
                <>
                  <button className="w-full text-left px-3 py-2 text-sm text-purple-600 hover:bg-purple-50 rounded-lg transition-colors">
                    User Management
                  </button>
                  <button className="w-full text-left px-3 py-2 text-sm text-yellow-600 hover:bg-yellow-50 rounded-lg transition-colors">
                    Content Moderation
                  </button>
                  <button className="w-full text-left px-3 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                    System Settings
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Location Info (for government users) */}
          {user.role === 'government' && user.jurisdiction && (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center space-x-2">
                <MapPin className="w-5 h-5 text-red-600" />
                <span>Your Jurisdiction</span>
              </h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Province:</span>
                  <span className="font-medium text-gray-900">{user.jurisdiction.province}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">District:</span>
                  <span className="font-medium text-gray-900">{user.jurisdiction.district}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Municipality:</span>
                  <span className="font-medium text-gray-900">{user.jurisdiction.municipality}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Ward:</span>
                  <span className="font-medium text-gray-900">{user.jurisdiction.ward}</span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;