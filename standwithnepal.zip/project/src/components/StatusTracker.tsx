import React from 'react';
import { CheckCircle, Clock, AlertTriangle, Eye, Calendar, User } from 'lucide-react';

interface StatusUpdate {
  id: string;
  status: 'New' | 'Acknowledged' | 'In Progress' | 'Resolved';
  timestamp: string;
  updatedBy: string;
  message?: string;
  department?: string;
}

interface StatusTrackerProps {
  currentStatus: 'New' | 'Acknowledged' | 'In Progress' | 'Resolved';
  statusHistory: StatusUpdate[];
  createdAt: string;
  createdBy: string;
  isAnonymous?: boolean;
}

const StatusTracker: React.FC<StatusTrackerProps> = ({
  currentStatus,
  statusHistory,
  createdAt,
  createdBy,
  isAnonymous = false
}) => {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'New':
        return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
      case 'Acknowledged':
        return <Eye className="w-5 h-5 text-blue-600" />;
      case 'In Progress':
        return <Clock className="w-5 h-5 text-orange-600" />;
      case 'Resolved':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      default:
        return <AlertTriangle className="w-5 h-5 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'New':
        return 'bg-yellow-100 border-yellow-200';
      case 'Acknowledged':
        return 'bg-blue-100 border-blue-200';
      case 'In Progress':
        return 'bg-orange-100 border-orange-200';
      case 'Resolved':
        return 'bg-green-100 border-green-200';
      default:
        return 'bg-gray-100 border-gray-200';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTimeElapsed = (startDate: string, endDate?: string) => {
    const start = new Date(startDate);
    const end = endDate ? new Date(endDate) : new Date();
    const diffInHours = Math.floor((end.getTime() - start.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
      return `${diffInHours} hours`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays} days`;
    }
  };

  // Create complete timeline including initial creation
  const completeTimeline = [
    {
      id: 'created',
      status: 'New' as const,
      timestamp: createdAt,
      updatedBy: isAnonymous ? 'Anonymous Citizen' : createdBy,
      message: 'Issue reported by citizen'
    },
    ...statusHistory
  ];

  const currentStatusUpdate = statusHistory.find(update => update.status === currentStatus);
  const resolvedUpdate = statusHistory.find(update => update.status === 'Resolved');

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Issue Status</h3>
        <div className={`flex items-center space-x-2 px-3 py-2 rounded-lg border ${getStatusColor(currentStatus)}`}>
          {getStatusIcon(currentStatus)}
          <span className="font-medium text-gray-900">{currentStatus}</span>
        </div>
      </div>

      {/* Status Progress Bar */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-gray-700">Progress</span>
          <span className="text-sm text-gray-500">
            {currentStatus === 'Resolved' ? '100%' : 
             currentStatus === 'In Progress' ? '75%' :
             currentStatus === 'Acknowledged' ? '50%' : '25%'}
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className={`h-2 rounded-full transition-all duration-500 ${
              currentStatus === 'Resolved' ? 'bg-green-600' :
              currentStatus === 'In Progress' ? 'bg-orange-600' :
              currentStatus === 'Acknowledged' ? 'bg-blue-600' : 'bg-yellow-600'
            }`}
            style={{
              width: currentStatus === 'Resolved' ? '100%' : 
                     currentStatus === 'In Progress' ? '75%' :
                     currentStatus === 'Acknowledged' ? '50%' : '25%'
            }}
          ></div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-1">
            <Calendar className="w-4 h-4 text-gray-500" />
            <span className="text-sm font-medium text-gray-700">Time Elapsed</span>
          </div>
          <p className="text-lg font-semibold text-gray-900">
            {getTimeElapsed(createdAt, resolvedUpdate?.timestamp)}
          </p>
        </div>

        <div className="bg-gray-50 rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-1">
            <User className="w-4 h-4 text-gray-500" />
            <span className="text-sm font-medium text-gray-700">Last Updated</span>
          </div>
          <p className="text-lg font-semibold text-gray-900">
            {currentStatusUpdate ? getTimeElapsed(currentStatusUpdate.timestamp) + ' ago' : 'Just now'}
          </p>
        </div>
      </div>

      {/* Timeline */}
      <div className="space-y-4">
        <h4 className="font-medium text-gray-900">Timeline</h4>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-gray-200"></div>
          
          <div className="space-y-6">
            {completeTimeline.map((update, index) => {
              const isActive = update.status === currentStatus;
              const isPast = completeTimeline.findIndex(u => u.status === currentStatus) > index;
              
              return (
                <div key={update.id} className="relative flex items-start space-x-4">
                  {/* Timeline dot */}
                  <div className={`relative z-10 flex items-center justify-center w-12 h-12 rounded-full border-2 ${
                    isActive ? getStatusColor(update.status) + ' border-current' :
                    isPast ? 'bg-gray-100 border-gray-300' :
                    'bg-white border-gray-300'
                  }`}>
                    {getStatusIcon(update.status)}
                  </div>
                  
                  {/* Content */}
                  <div className="flex-1 min-w-0 pb-6">
                    <div className="flex items-center justify-between">
                      <h5 className={`font-medium ${isActive ? 'text-gray-900' : 'text-gray-700'}`}>
                        {update.status}
                      </h5>
                      <span className="text-sm text-gray-500">
                        {formatDate(update.timestamp)}
                      </span>
                    </div>
                    
                    <p className="text-sm text-gray-600 mt-1">
                      Updated by: {update.updatedBy}
                    </p>
                    
                    {update.department && (
                      <p className="text-sm text-blue-600 mt-1">
                        Assigned to: {update.department}
                      </p>
                    )}
                    
                    {update.message && (
                      <div className="mt-2 p-3 bg-gray-50 rounded-lg">
                        <p className="text-sm text-gray-700">{update.message}</p>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Expected Resolution Time */}
      {currentStatus !== 'Resolved' && (
        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Clock className="w-4 h-4 text-blue-600" />
            <span className="font-medium text-blue-900">Expected Resolution</span>
          </div>
          <p className="text-sm text-blue-800">
            Based on similar issues, this typically takes 3-7 business days to resolve.
            You'll receive notifications as the status updates.
          </p>
        </div>
      )}
    </div>
  );
};

export default StatusTracker;