import React, { useState } from 'react';
import { CheckCircle, Clock, AlertTriangle, MessageSquare, Calendar, MapPin, Eye, FileText } from 'lucide-react';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'citizen' | 'government' | 'admin';
  jurisdiction?: {
    province: string;
    district: string;
    municipality: string;
    ward: string;
  };
  isVerified: boolean;
}

interface GovernmentDashboardProps {
  user: User | null;
}

interface Issue {
  id: string;
  title: string;
  description: string;
  category: string;
  location: {
    province: string;
    district: string;
    municipality: string;
    ward: string;
  };
  status: 'New' | 'Acknowledged' | 'In Progress' | 'Resolved';
  severity: 'low' | 'medium' | 'high' | 'urgent';
  upvotes: number;
  comments: number;
  reportedBy: string;
  isAnonymous: boolean;
  createdAt: string;
  updatedAt: string;
  assignedDepartment?: string;
  governmentResponse?: string;
}

const GovernmentDashboard: React.FC<GovernmentDashboardProps> = ({ user }) => {
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedSeverity, setSelectedSeverity] = useState('all');
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);
  const [updateData, setUpdateData] = useState({
    status: '',
    response: '',
    department: ''
  });

  // Mock data - filtered by user's jurisdiction
  const issues: Issue[] = [
    {
      id: '1',
      title: 'Broken streetlight near Ratna Park',
      description: 'The streetlight has been broken for over a week, making the area unsafe during night hours.',
      category: 'Electricity',
      location: {
        province: 'Bagmati Province',
        district: 'Kathmandu',
        municipality: 'Kathmandu Metropolitan City',
        ward: '1'
      },
      status: 'In Progress',
      severity: 'high',
      upvotes: 23,
      comments: 5,
      reportedBy: 'Sita Sharma',
      isAnonymous: false,
      createdAt: '2024-01-15T10:30:00Z',
      updatedAt: '2024-01-16T14:20:00Z',
      assignedDepartment: 'Electricity Department',
      governmentResponse: 'Issue has been assigned to the maintenance team. Expected resolution within 3 days.'
    },
    {
      id: '2',
      title: 'Water shortage in Tarkeshwar area',
      description: 'Residents have been without water supply for 3 days. The local water tank seems to be empty.',
      category: 'Water Supply',
      location: {
        province: 'Bagmati Province',
        district: 'Kathmandu',
        municipality: 'Kathmandu Metropolitan City',
        ward: '12'
      },
      status: 'Acknowledged',
      severity: 'urgent',
      upvotes: 45,
      comments: 12,
      reportedBy: 'Anonymous',
      isAnonymous: true,
      createdAt: '2024-01-14T08:15:00Z',
      updatedAt: '2024-01-15T09:45:00Z',
      assignedDepartment: 'Water Department',
      governmentResponse: 'We acknowledge this critical issue and are investigating the cause of the water shortage.'
    }
  ];

  const stats = {
    newIssues: 15,
    inProgress: 8,
    resolved: 23,
    totalThisMonth: 46,
    averageResponseTime: 2.3 // days
  };

  const departments = [
    'Road Department',
    'Electricity Department',
    'Water Department',
    'Health Department',
    'Education Department',
    'Environment Department',
    'Public Safety',
    'Administrative'
  ];

  if (!user || (user.role !== 'government' && user.role !== 'admin')) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <AlertTriangle className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Access Restricted</h2>
        <p className="text-gray-600">
          This dashboard is only accessible to government officials and administrators.
        </p>
      </div>
    );
  }

  const filteredIssues = issues.filter(issue => {
    const matchesStatus = selectedStatus === 'all' || issue.status === selectedStatus;
    const matchesSeverity = selectedSeverity === 'all' || issue.severity === selectedSeverity;
    return matchesStatus && matchesSeverity;
  });

  const handleUpdateIssue = (issue: Issue) => {
    setSelectedIssue(issue);
    setUpdateData({
      status: issue.status,
      response: issue.governmentResponse || '',
      department: issue.assignedDepartment || ''
    });
    setShowUpdateModal(true);
  };

  const handleSaveUpdate = () => {
    // In real app, this would call API to update the issue
    console.log('Updating issue:', selectedIssue?.id, updateData);
    setShowUpdateModal(false);
    setSelectedIssue(null);
    // Show success message
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'New':
        return 'bg-yellow-100 text-yellow-800';
      case 'Acknowledged':
        return 'bg-blue-100 text-blue-800';
      case 'In Progress':
        return 'bg-orange-100 text-orange-800';
      case 'Resolved':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low':
        return 'bg-green-100 text-green-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'high':
        return 'bg-orange-100 text-orange-800';
      case 'urgent':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Government Dashboard</h1>
        <p className="text-gray-600">
          Manage and respond to citizen issues in your jurisdiction: {user.jurisdiction?.municipality}, Ward {user.jurisdiction?.ward}
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="p-2 bg-yellow-50 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-yellow-600" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-600">New Issues</p>
              <p className="text-2xl font-bold text-gray-900">{stats.newIssues}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="p-2 bg-orange-50 rounded-lg">
              <Clock className="w-5 h-5 text-orange-600" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-600">In Progress</p>
              <p className="text-2xl font-bold text-gray-900">{stats.inProgress}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="p-2 bg-green-50 rounded-lg">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-600">Resolved</p>
              <p className="text-2xl font-bold text-gray-900">{stats.resolved}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="p-2 bg-blue-50 rounded-lg">
              <Calendar className="w-5 h-5 text-blue-600" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-600">This Month</p>
              <p className="text-2xl font-bold text-gray-900">{stats.totalThisMonth}</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
          <div className="flex items-center">
            <div className="p-2 bg-purple-50 rounded-lg">
              <Clock className="w-5 h-5 text-purple-600" />
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-600">Avg Response</p>
              <p className="text-2xl font-bold text-gray-900">{stats.averageResponseTime}d</p>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
          <h2 className="text-lg font-semibold text-gray-900">Issues in Your Jurisdiction</h2>
          
          <div className="flex items-center space-x-4">
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
            >
              <option value="all">All Statuses</option>
              <option value="New">New</option>
              <option value="Acknowledged">Acknowledged</option>
              <option value="In Progress">In Progress</option>
              <option value="Resolved">Resolved</option>
            </select>

            <select
              value={selectedSeverity}
              onChange={(e) => setSelectedSeverity(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
            >
              <option value="all">All Severities</option>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="urgent">Urgent</option>
            </select>
          </div>
        </div>
      </div>

      {/* Issues List */}
      <div className="space-y-6">
        {filteredIssues.map((issue) => (
          <div key={issue.id} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex-1">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{issue.title}</h3>
                <p className="text-gray-600 mb-4">{issue.description}</p>
                
                <div className="flex flex-wrap items-center gap-2 mb-4">
                  <span className="bg-gray-100 px-3 py-1 rounded-full text-sm font-medium text-gray-700">
                    {issue.category}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(issue.status)}`}>
                    {issue.status}
                  </span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getSeverityColor(issue.severity)}`}>
                    {issue.severity.charAt(0).toUpperCase() + issue.severity.slice(1)}
                  </span>
                  {issue.assignedDepartment && (
                    <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                      {issue.assignedDepartment}
                    </span>
                  )}
                </div>

                <div className="flex items-center space-x-6 text-sm text-gray-500 mb-4">
                  <span className="flex items-center space-x-1">
                    <MapPin className="w-4 h-4" />
                    <span>Ward {issue.location.ward}</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>{new Date(issue.createdAt).toLocaleDateString()}</span>
                  </span>
                  <span>By: {issue.isAnonymous ? 'Anonymous' : issue.reportedBy}</span>
                  <span className="flex items-center space-x-1">
                    <Eye className="w-4 h-4" />
                    <span>{issue.upvotes} upvotes</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <MessageSquare className="w-4 h-4" />
                    <span>{issue.comments} comments</span>
                  </span>
                </div>

                {issue.governmentResponse && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                    <h4 className="font-medium text-blue-900 mb-2">Government Response:</h4>
                    <p className="text-blue-800">{issue.governmentResponse}</p>
                  </div>
                )}
              </div>
            </div>

            <div className="flex items-center justify-between pt-4 border-t border-gray-200">
              <div className="flex items-center space-x-2">
                {issue.status === 'New' && (
                  <span className="text-sm text-yellow-600 font-medium">Requires attention</span>
                )}
                {issue.severity === 'urgent' && (
                  <span className="text-sm text-red-600 font-medium">Urgent priority</span>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleUpdateIssue(issue)}
                  className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-red-700 transition-colors"
                >
                  Update Status
                </button>
                <button className="text-gray-600 hover:text-gray-900 px-4 py-2 rounded-lg text-sm font-medium border border-gray-300 hover:bg-gray-50 transition-colors">
                  View Details
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Update Modal */}
      {showUpdateModal && selectedIssue && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-full max-w-md">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Update Issue Status</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                <select
                  value={updateData.status}
                  onChange={(e) => setUpdateData(prev => ({ ...prev, status: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                >
                  <option value="New">New</option>
                  <option value="Acknowledged">Acknowledged</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Assign Department</label>
                <select
                  value={updateData.department}
                  onChange={(e) => setUpdateData(prev => ({ ...prev, department: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                >
                  <option value="">Select Department</option>
                  {departments.map((dept) => (
                    <option key={dept} value={dept}>{dept}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Response Message</label>
                <textarea
                  value={updateData.response}
                  onChange={(e) => setUpdateData(prev => ({ ...prev, response: e.target.value }))}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                  placeholder="Provide an update to citizens..."
                />
              </div>
            </div>

            <div className="flex items-center justify-end space-x-3 mt-6">
              <button
                onClick={() => setShowUpdateModal(false)}
                className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveUpdate}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
              >
                Save Update
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GovernmentDashboard;