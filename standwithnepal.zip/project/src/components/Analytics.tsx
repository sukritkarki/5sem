import React from 'react';
import { BarChart3, TrendingUp, Users, AlertCircle, CheckCircle, Clock, MapPin } from 'lucide-react';
import QuickStats from './QuickStats';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'citizen' | 'government' | 'admin';
  jurisdiction?: {
    province: string;
    district: string;
    municipality: string;
    ward: string;
  };
  isVerified: boolean;
}

interface AnalyticsProps {
  user: User | null;
}

const Analytics: React.FC<AnalyticsProps> = ({ user }) => {
  // Mock data - in real app, this would come from API
  const quickStatsData = [
    {
      label: 'Total Issues',
      value: 2847,
      change: { value: 12, type: 'increase' as const, period: 'last month' },
      icon: BarChart3,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      label: 'Resolution Rate',
      value: 67.5,
      change: { value: 8, type: 'increase' as const, period: 'last month' },
      icon: CheckCircle,
      color: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      label: 'Active Users',
      value: 12450,
      change: { value: 15, type: 'increase' as const, period: 'last month' },
      icon: Users,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50'
    },
    {
      label: 'Avg Resolution Time',
      value: '12.5 days',
      change: { value: -5, type: 'decrease' as const, period: 'last month' },
      icon: Clock,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50'
    }
  ];

  const categoryData = [
    { name: 'Road Infrastructure', count: 485, percentage: 17.0 },
    { name: 'Water Supply', count: 423, percentage: 14.9 },
    { name: 'Electricity', count: 398, percentage: 14.0 },
    { name: 'Sanitation', count: 312, percentage: 11.0 },
    { name: 'Healthcare', count: 289, percentage: 10.1 },
    { name: 'Public Safety', count: 267, percentage: 9.4 },
    { name: 'Transportation', count: 234, percentage: 8.2 },
    { name: 'Environment', count: 189, percentage: 6.6 },
    { name: 'Other', count: 250, percentage: 8.8 }
  ];

  const locationData = [
    { location: 'Kathmandu Metropolitan City', issues: 892, resolved: 623 },
    { location: 'Lalitpur Metropolitan City', issues: 456, resolved: 298 },
    { location: 'Bhaktapur Municipality', issues: 234, resolved: 167 },
    { location: 'Pokhara Metropolitan City', issues: 345, resolved: 256 },
    { location: 'Biratnagar Metropolitan City', issues: 287, resolved: 198 }
  ];

  const resolutionTrends = [
    { month: 'Jan', reported: 234, resolved: 198 },
    { month: 'Feb', reported: 287, resolved: 234 },
    { month: 'Mar', reported: 345, resolved: 298 },
    { month: 'Apr', reported: 298, reported: 256 },
    { month: 'May', reported: 312, resolved: 278 },
    { month: 'Jun', reported: 289, resolved: 245 }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Analytics Dashboard</h1>
        <p className="text-gray-600">
          Insights into citizen issues, government responsiveness, and community engagement.
        </p>
      </div>

      {/* Key Metrics */}
      <div className="mb-8">
        <QuickStats 
          stats={quickStatsData}
          title="Platform Analytics"
          showTrends={true}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Issues by Category */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Issues by Category</h3>
          <div className="space-y-4">
            {categoryData.map((category, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm font-medium text-gray-700">{category.name}</span>
                    <span className="text-sm text-gray-500">{category.count}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-red-600 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${category.percentage}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Top Performing Locations */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Performance by Location</h3>
          <div className="space-y-4">
            {locationData.map((location, index) => (
              <div key={index} className="border-b border-gray-100 pb-4 last:border-b-0">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-gray-900">{location.location}</h4>
                  <span className="text-sm text-gray-500">
                    {Math.round((location.resolved / location.issues) * 100)}% resolved
                  </span>
                </div>
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <span>{location.issues} total issues</span>
                  <span>{location.resolved} resolved</span>
                  <span>{location.issues - location.resolved} pending</span>
                </div>
                <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-green-600 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${(location.resolved / location.issues) * 100}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Resolution Trends */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Resolution Trends</h3>
          <div className="h-64 flex items-end justify-between space-x-2">
            {resolutionTrends.map((data, index) => (
              <div key={index} className="flex-1 flex flex-col items-center">
                <div className="w-full flex flex-col items-center space-y-1 mb-2">
                  <div
                    className="w-full bg-red-200 rounded-t"
                    style={{ height: `${(data.reported / 400) * 200}px` }}
                  ></div>
                  <div
                    className="w-full bg-green-500 rounded-b"
                    style={{ height: `${(data.resolved / 400) * 200}px` }}
                  ></div>
                </div>
                <span className="text-xs text-gray-600">{data.month}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-center space-x-6 mt-4 text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-red-200 rounded"></div>
              <span>Reported</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-3 h-3 bg-green-500 rounded"></div>
              <span>Resolved</span>
            </div>
          </div>
        </div>

        {/* Community Engagement */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-6">Community Engagement</h3>
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-blue-50 rounded-lg">
                  <Users className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">Active Citizens</p>
                  <p className="text-sm text-gray-600">Users who reported issues</p>
                </div>
              </div>
              <span className="text-2xl font-bold text-gray-900">12,450</span>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-red-50 rounded-lg">
                  <MapPin className="w-5 h-5 text-red-600" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">Government Officials</p>
                  <p className="text-sm text-gray-600">Registered representatives</p>
                </div>
              </div>
              <span className="text-2xl font-bold text-gray-900">156</span>
            </div>

            <div className="pt-4 border-t border-gray-200">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">67.5%</p>
                <p className="text-sm text-gray-600 mt-1">Overall Resolution Rate</p>
              </div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-medium text-gray-900 mb-2">Key Insights</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Road infrastructure issues are most common</li>
                <li>• Kathmandu has highest engagement</li>
                <li>• Resolution time improved by 15% this month</li>
                <li>• Water supply issues need more attention</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;