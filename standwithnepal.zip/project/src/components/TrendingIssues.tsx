import React, { useState } from 'react';
import { TrendingUp, MapPin, ThumbsUp, MessageSquare, Calendar, Filter } from 'lucide-react';

interface TrendingIssue {
  id: string;
  title: string;
  category: string;
  location: {
    municipality: string;
    ward: string;
  };
  upvotes: number;
  comments: number;
  createdAt: string;
  trendScore: number;
  status: 'New' | 'Acknowledged' | 'In Progress' | 'Resolved';
}

interface TrendingIssuesProps {
  timeframe?: 'today' | 'week' | 'month';
  limit?: number;
  showFilters?: boolean;
}

const TrendingIssues: React.FC<TrendingIssuesProps> = ({
  timeframe = 'week',
  limit = 10,
  showFilters = true
}) => {
  const [selectedTimeframe, setSelectedTimeframe] = useState(timeframe);
  const [selectedCategory, setSelectedCategory] = useState('all');

  // Mock trending issues data
  const trendingIssues: TrendingIssue[] = [
    {
      id: '1',
      title: 'Potholes on Ring Road causing traffic jams',
      category: 'Road Infrastructure',
      location: { municipality: 'Kathmandu Metropolitan City', ward: '10' },
      upvotes: 156,
      comments: 23,
      createdAt: '2024-01-14T08:00:00Z',
      trendScore: 95,
      status: 'Acknowledged'
    },
    {
      id: '2',
      title: 'Water shortage affecting entire neighborhood',
      category: 'Water Supply',
      location: { municipality: 'Lalitpur Metropolitan City', ward: '5' },
      upvotes: 134,
      comments: 18,
      createdAt: '2024-01-15T10:30:00Z',
      trendScore: 88,
      status: 'In Progress'
    },
    {
      id: '3',
      title: 'Frequent power outages during peak hours',
      category: 'Electricity',
      location: { municipality: 'Bhaktapur Municipality', ward: '3' },
      upvotes: 98,
      comments: 15,
      createdAt: '2024-01-13T16:45:00Z',
      trendScore: 82,
      status: 'New'
    },
    {
      id: '4',
      title: 'Garbage collection not happening regularly',
      category: 'Sanitation',
      location: { municipality: 'Pokhara Metropolitan City', ward: '12' },
      upvotes: 87,
      comments: 12,
      createdAt: '2024-01-16T09:15:00Z',
      trendScore: 76,
      status: 'Acknowledged'
    },
    {
      id: '5',
      title: 'Broken streetlights making area unsafe',
      category: 'Public Safety',
      location: { municipality: 'Kathmandu Metropolitan City', ward: '1' },
      upvotes: 72,
      comments: 9,
      createdAt: '2024-01-15T14:20:00Z',
      trendScore: 71,
      status: 'In Progress'
    }
  ];

  const categories = [
    'Road Infrastructure',
    'Water Supply',
    'Electricity',
    'Sanitation',
    'Public Safety',
    'Healthcare',
    'Education',
    'Environment'
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'New':
        return 'bg-yellow-100 text-yellow-800';
      case 'Acknowledged':
        return 'bg-blue-100 text-blue-800';
      case 'In Progress':
        return 'bg-orange-100 text-orange-800';
      case 'Resolved':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays}d ago`;
    }
  };

  const getTrendIcon = (score: number) => {
    if (score >= 90) return '🔥';
    if (score >= 80) return '📈';
    if (score >= 70) return '⬆️';
    return '📊';
  };

  const filteredIssues = trendingIssues
    .filter(issue => selectedCategory === 'all' || issue.category === selectedCategory)
    .slice(0, limit);

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-red-600" />
            <h3 className="text-lg font-semibold text-gray-900">Trending Issues</h3>
          </div>
          
          {showFilters && (
            <div className="flex items-center space-x-3">
              <select
                value={selectedTimeframe}
                onChange={(e) => setSelectedTimeframe(e.target.value as any)}
                className="text-sm border border-gray-300 rounded-lg px-3 py-1 focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="today">Today</option>
                <option value="week">This Week</option>
                <option value="month">This Month</option>
              </select>
              
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="text-sm border border-gray-300 rounded-lg px-3 py-1 focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="all">All Categories</option>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
      </div>

      {/* Trending Issues List */}
      <div className="divide-y divide-gray-200">
        {filteredIssues.map((issue, index) => (
          <div key={issue.id} className="p-6 hover:bg-gray-50 transition-colors cursor-pointer">
            <div className="flex items-start space-x-4">
              {/* Rank and Trend Indicator */}
              <div className="flex flex-col items-center space-y-1">
                <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                  <span className="text-sm font-bold text-red-600">#{index + 1}</span>
                </div>
                <span className="text-lg">{getTrendIcon(issue.trendScore)}</span>
              </div>

              {/* Issue Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="text-lg font-medium text-gray-900 line-clamp-2">
                    {issue.title}
                  </h4>
                  <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium whitespace-nowrap ${getStatusColor(issue.status)}`}>
                    {issue.status}
                  </span>
                </div>

                <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                  <span className="bg-gray-100 px-2 py-1 rounded-full text-xs font-medium">
                    {issue.category}
                  </span>
                  <span className="flex items-center space-x-1">
                    <MapPin className="w-3 h-3" />
                    <span>{issue.location.municipality}, Ward {issue.location.ward}</span>
                  </span>
                  <span className="flex items-center space-x-1">
                    <Calendar className="w-3 h-3" />
                    <span>{formatTimeAgo(issue.createdAt)}</span>
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <span className="flex items-center space-x-1">
                      <ThumbsUp className="w-4 h-4" />
                      <span>{issue.upvotes}</span>
                    </span>
                    <span className="flex items-center space-x-1">
                      <MessageSquare className="w-4 h-4" />
                      <span>{issue.comments}</span>
                    </span>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-gray-500">Trend Score:</span>
                    <div className="w-16 bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-red-600 h-2 rounded-full"
                        style={{ width: `${issue.trendScore}%` }}
                      ></div>
                    </div>
                    <span className="text-xs font-medium text-gray-700">{issue.trendScore}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="p-4 bg-gray-50 text-center border-t border-gray-200">
        <button className="text-sm text-red-600 hover:text-red-700 font-medium">
          View All Trending Issues
        </button>
      </div>

      {/* Empty State */}
      {filteredIssues.length === 0 && (
        <div className="p-8 text-center">
          <TrendingUp className="w-12 h-12 text-gray-400 mx-auto mb-3" />
          <h4 className="text-lg font-medium text-gray-900 mb-2">No Trending Issues</h4>
          <p className="text-gray-600">
            No issues are trending in the selected category and timeframe.
          </p>
        </div>
      )}
    </div>
  );
};

export default TrendingIssues;