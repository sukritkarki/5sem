import React, { useState, useEffect } from 'react';
import { MapPin, ChevronDown } from 'lucide-react';

interface LocationData {
  provinces: string[];
  districts: { [key: string]: string[] };
  municipalities: { [key: string]: string[] };
  wards: { [key: string]: number };
}

interface LocationSelectorProps {
  onLocationChange: (location: {
    province: string;
    district: string;
    municipality: string;
    ward: string;
  }) => void;
  initialLocation?: {
    province: string;
    district: string;
    municipality: string;
    ward: string;
  };
  required?: boolean;
}

const LocationSelector: React.FC<LocationSelectorProps> = ({
  onLocationChange,
  initialLocation,
  required = false
}) => {
  const [selectedProvince, setSelectedProvince] = useState(initialLocation?.province || '');
  const [selectedDistrict, setSelectedDistrict] = useState(initialLocation?.district || '');
  const [selectedMunicipality, setSelectedMunicipality] = useState(initialLocation?.municipality || '');
  const [selectedWard, setSelectedWard] = useState(initialLocation?.ward || '');

  // Nepal administrative data
  const locationData: LocationData = {
    provinces: [
      'Province 1',
      'Madhesh Province',
      'Bagmati Province',
      'Gandaki Province',
      'Lumbini Province',
      'Karnali Province',
      'Sudurpashchim Province'
    ],
    districts: {
      'Province 1': ['Bhojpur', 'Dhankuta', 'Ilam', 'Jhapa', 'Khotang', 'Morang', 'Okhaldhunga', 'Panchthar', 'Sankhuwasabha', 'Solukhumbu', 'Sunsari', 'Taplejung', 'Terhathum', 'Udayapur'],
      'Madhesh Province': ['Bara', 'Dhanusha', 'Mahottari', 'Parsa', 'Rautahat', 'Saptari', 'Sarlahi', 'Siraha'],
      'Bagmati Province': ['Bhaktapur', 'Chitwan', 'Dhading', 'Dolakha', 'Kathmandu', 'Kavrepalanchok', 'Lalitpur', 'Makwanpur', 'Nuwakot', 'Ramechhap', 'Rasuwa', 'Sindhuli', 'Sindhupalchok'],
      'Gandaki Province': ['Baglung', 'Gorkha', 'Kaski', 'Lamjung', 'Manang', 'Mustang', 'Myagdi', 'Nawalpur', 'Parbat', 'Syangja', 'Tanahun'],
      'Lumbini Province': ['Arghakhanchi', 'Banke', 'Bardiya', 'Dang', 'Gulmi', 'Kapilvastu', 'Palpa', 'Parasi', 'Pyuthan', 'Rolpa', 'Rukum East', 'Rupandehi'],
      'Karnali Province': ['Dailekh', 'Dolpa', 'Humla', 'Jajarkot', 'Jumla', 'Kalikot', 'Mugu', 'Rukum West', 'Salyan', 'Surkhet'],
      'Sudurpashchim Province': ['Achham', 'Baitadi', 'Bajhang', 'Bajura', 'Dadeldhura', 'Darchula', 'Doti', 'Kailali', 'Kanchanpur']
    },
    municipalities: {
      'Kathmandu': ['Kathmandu Metropolitan City', 'Lalitpur Metropolitan City', 'Bhaktapur Municipality', 'Kirtipur Municipality', 'Madhyapur Thimi Municipality', 'Budhanilkantha Municipality', 'Chandragiri Municipality', 'Dakshinkali Municipality', 'Gokarneshwar Municipality', 'Kageshwari Manohara Municipality', 'Nagarjun Municipality', 'Shankhrapur Municipality', 'Tarakeshwar Municipality', 'Tokha Municipality'],
      'Lalitpur': ['Lalitpur Metropolitan City', 'Godawari Municipality', 'Mahalaxmi Municipality'],
      'Bhaktapur': ['Bhaktapur Municipality', 'Changunarayan Municipality', 'Madhyapur Thimi Municipality', 'Suryabinayak Municipality'],
      'Chitwan': ['Bharatpur Metropolitan City', 'Kalika Municipality', 'Khairahani Municipality', 'Madi Municipality', 'Ratnanagar Municipality', 'Rapti Municipality', 'Ichchhakamana Rural Municipality'],
      'Kaski': ['Pokhara Metropolitan City', 'Annapurna Rural Municipality', 'Machhapuchchhre Rural Municipality', 'Madi Rural Municipality', 'Rupa Rural Municipality']
    },
    wards: {
      'Kathmandu Metropolitan City': 32,
      'Lalitpur Metropolitan City': 29,
      'Bhaktapur Municipality': 10,
      'Pokhara Metropolitan City': 33,
      'Bharatpur Metropolitan City': 29
    }
  };

  useEffect(() => {
    if (selectedProvince && selectedDistrict && selectedMunicipality && selectedWard) {
      onLocationChange({
        province: selectedProvince,
        district: selectedDistrict,
        municipality: selectedMunicipality,
        ward: selectedWard
      });
    }
  }, [selectedProvince, selectedDistrict, selectedMunicipality, selectedWard, onLocationChange]);

  const handleProvinceChange = (province: string) => {
    setSelectedProvince(province);
    setSelectedDistrict('');
    setSelectedMunicipality('');
    setSelectedWard('');
  };

  const handleDistrictChange = (district: string) => {
    setSelectedDistrict(district);
    setSelectedMunicipality('');
    setSelectedWard('');
  };

  const handleMunicipalityChange = (municipality: string) => {
    setSelectedMunicipality(municipality);
    setSelectedWard('');
  };

  const getAvailableDistricts = () => {
    return selectedProvince ? locationData.districts[selectedProvince] || [] : [];
  };

  const getAvailableMunicipalities = () => {
    return selectedDistrict ? locationData.municipalities[selectedDistrict] || [] : [];
  };

  const getAvailableWards = () => {
    const wardCount = selectedMunicipality ? locationData.wards[selectedMunicipality] || 15 : 0;
    return Array.from({ length: wardCount }, (_, i) => (i + 1).toString());
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center space-x-2 mb-4">
        <MapPin className="w-5 h-5 text-red-600" />
        <h3 className="text-lg font-semibold text-gray-900">Location Information</h3>
        {required && <span className="text-red-500">*</span>}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Province */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Province {required && <span className="text-red-500">*</span>}
          </label>
          <div className="relative">
            <select
              value={selectedProvince}
              onChange={(e) => handleProvinceChange(e.target.value)}
              required={required}
              className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 appearance-none bg-white"
            >
              <option value="">Select Province</option>
              {locationData.provinces.map((province) => (
                <option key={province} value={province}>
                  {province}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 pointer-events-none" />
          </div>
        </div>

        {/* District */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            District {required && <span className="text-red-500">*</span>}
          </label>
          <div className="relative">
            <select
              value={selectedDistrict}
              onChange={(e) => handleDistrictChange(e.target.value)}
              required={required}
              disabled={!selectedProvince}
              className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 appearance-none bg-white disabled:bg-gray-100 disabled:cursor-not-allowed"
            >
              <option value="">Select District</option>
              {getAvailableDistricts().map((district) => (
                <option key={district} value={district}>
                  {district}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 pointer-events-none" />
          </div>
        </div>

        {/* Municipality */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Municipality/Rural Municipality {required && <span className="text-red-500">*</span>}
          </label>
          <div className="relative">
            <select
              value={selectedMunicipality}
              onChange={(e) => handleMunicipalityChange(e.target.value)}
              required={required}
              disabled={!selectedDistrict}
              className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 appearance-none bg-white disabled:bg-gray-100 disabled:cursor-not-allowed"
            >
              <option value="">Select Municipality</option>
              {getAvailableMunicipalities().map((municipality) => (
                <option key={municipality} value={municipality}>
                  {municipality}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 pointer-events-none" />
          </div>
        </div>

        {/* Ward */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Ward Number {required && <span className="text-red-500">*</span>}
          </label>
          <div className="relative">
            <select
              value={selectedWard}
              onChange={(e) => setSelectedWard(e.target.value)}
              required={required}
              disabled={!selectedMunicipality}
              className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 appearance-none bg-white disabled:bg-gray-100 disabled:cursor-not-allowed"
            >
              <option value="">Select Ward</option>
              {getAvailableWards().map((ward) => (
                <option key={ward} value={ward}>
                  Ward {ward}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Location Summary */}
      {selectedProvince && selectedDistrict && selectedMunicipality && selectedWard && (
        <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
          <h4 className="font-medium text-green-900 mb-2">Selected Location:</h4>
          <p className="text-green-800">
            {selectedMunicipality}, Ward {selectedWard}, {selectedDistrict}, {selectedProvince}
          </p>
        </div>
      )}
    </div>
  );
};

export default LocationSelector;