import React, { useState } from 'react';
import { Filter, X, MapPin, Calendar, Tag, TrendingUp } from 'lucide-react';

interface FilterOptions {
  category: string;
  status: string;
  severity: string;
  location: string;
  dateRange: string;
  sortBy: string;
}

interface IssueFiltersProps {
  filters: FilterOptions;
  onFilterChange: (filters: FilterOptions) => void;
  categories: string[];
  locations: string[];
  showAdvanced?: boolean;
}

const IssueFilters: React.FC<IssueFiltersProps> = ({
  filters,
  onFilterChange,
  categories,
  locations,
  showAdvanced = true
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const handleFilterChange = (key: keyof FilterOptions, value: string) => {
    const newFilters = { ...filters, [key]: value };
    onFilterChange(newFilters);
  };

  const clearAllFilters = () => {
    const clearedFilters: FilterOptions = {
      category: '',
      status: '',
      severity: '',
      location: '',
      dateRange: '',
      sortBy: 'recent'
    };
    onFilterChange(clearedFilters);
  };

  const getActiveFilterCount = () => {
    return Object.values(filters).filter(value => value && value !== 'recent').length;
  };

  const quickFilters = [
    {
      key: 'severity',
      value: 'urgent',
      label: 'Urgent',
      icon: TrendingUp,
      color: 'bg-red-100 text-red-800'
    },
    {
      key: 'status',
      value: 'New',
      label: 'New Issues',
      icon: Tag,
      color: 'bg-yellow-100 text-yellow-800'
    },
    {
      key: 'dateRange',
      value: 'today',
      label: 'Today',
      icon: Calendar,
      color: 'bg-blue-100 text-blue-800'
    },
    {
      key: 'sortBy',
      value: 'upvotes',
      label: 'Popular',
      icon: TrendingUp,
      color: 'bg-purple-100 text-purple-800'
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Filter className="w-5 h-5 text-gray-600" />
          <h3 className="font-medium text-gray-900">Filters</h3>
          {getActiveFilterCount() > 0 && (
            <span className="bg-red-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
              {getActiveFilterCount()}
            </span>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          {getActiveFilterCount() > 0 && (
            <button
              onClick={clearAllFilters}
              className="text-sm text-red-600 hover:text-red-700 font-medium"
            >
              Clear All
            </button>
          )}
          {showAdvanced && (
            <button
              onClick={() => setIsExpanded(!isExpanded)}
              className="text-sm text-gray-600 hover:text-gray-700 font-medium"
            >
              {isExpanded ? 'Less' : 'More'} Filters
            </button>
          )}
        </div>
      </div>

      {/* Quick Filters */}
      <div className="flex flex-wrap gap-2 mb-4">
        {quickFilters.map((filter) => {
          const Icon = filter.icon;
          const isActive = filters[filter.key as keyof FilterOptions] === filter.value;
          
          return (
            <button
              key={`${filter.key}-${filter.value}`}
              onClick={() => handleFilterChange(filter.key as keyof FilterOptions, isActive ? '' : filter.value)}
              className={`flex items-center space-x-1 px-3 py-1 rounded-full text-sm transition-colors ${
                isActive ? filter.color : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <Icon className="w-3 h-3" />
              <span>{filter.label}</span>
            </button>
          );
        })}
      </div>

      {/* Advanced Filters */}
      {isExpanded && (
        <div className="pt-4 border-t border-gray-200">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
              <select
                value={filters.category}
                onChange={(e) => handleFilterChange('category', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">All Categories</option>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
              <select
                value={filters.status}
                onChange={(e) => handleFilterChange('status', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">All Statuses</option>
                <option value="New">New</option>
                <option value="Acknowledged">Acknowledged</option>
                <option value="In Progress">In Progress</option>
                <option value="Resolved">Resolved</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Severity</label>
              <select
                value={filters.severity}
                onChange={(e) => handleFilterChange('severity', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">All Severities</option>
                <option value="low">Low</option>
                <option value="medium">Medium</option>
                <option value="high">High</option>
                <option value="urgent">Urgent</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
              <select
                value={filters.location}
                onChange={(e) => handleFilterChange('location', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">All Locations</option>
                {locations.map((location) => (
                  <option key={location} value={location}>
                    {location}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Date Range</label>
              <select
                value={filters.dateRange}
                onChange={(e) => handleFilterChange('dateRange', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="">All Time</option>
                <option value="today">Today</option>
                <option value="week">This Week</option>
                <option value="month">This Month</option>
                <option value="quarter">Last 3 Months</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Sort By</label>
              <select
                value={filters.sortBy}
                onChange={(e) => handleFilterChange('sortBy', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
              >
                <option value="recent">Most Recent</option>
                <option value="upvotes">Most Upvoted</option>
                <option value="comments">Most Discussed</option>
                <option value="severity">By Severity</option>
              </select>
            </div>
          </div>

          {/* Active Filters Summary */}
          {getActiveFilterCount() > 0 && (
            <div className="mt-4 p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">
                  {getActiveFilterCount()} filter{getActiveFilterCount() > 1 ? 's' : ''} applied
                </span>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(filters).map(([key, value]) => {
                    if (!value || value === 'recent') return null;
                    return (
                      <span
                        key={key}
                        className="inline-flex items-center space-x-1 bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs"
                      >
                        <span>{key}: {value}</span>
                        <button
                          onClick={() => handleFilterChange(key as keyof FilterOptions, '')}
                          className="hover:bg-red-200 rounded-full p-0.5"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default IssueFilters;