import React from 'react';
import { MapPin, ThumbsUp, MessageSquare, Calendar, User, Eye } from 'lucide-react';

interface Issue {
  id: string;
  title: string;
  description: string;
  category: string;
  location: {
    province: string;
    district: string;
    municipality: string;
    ward: string;
  };
  status: 'New' | 'Acknowledged' | 'In Progress' | 'Resolved';
  severity: 'low' | 'medium' | 'high' | 'urgent';
  upvotes: number;
  comments: number;
  reportedBy: string;
  isAnonymous: boolean;
  createdAt: string;
  images?: string[];
}

interface IssueCardProps {
  issue: Issue;
  onView: (issue: Issue) => void;
  onUpvote: (issueId: string) => void;
  showLocation?: boolean;
  compact?: boolean;
}

const IssueCard: React.FC<IssueCardProps> = ({
  issue,
  onView,
  onUpvote,
  showLocation = true,
  compact = false
}) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'New':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'Acknowledged':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'In Progress':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Resolved':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low':
        return 'bg-green-100 text-green-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'high':
        return 'bg-orange-100 text-orange-800';
      case 'urgent':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) {
      return 'Just now';
    } else if (diffInHours < 24) {
      return `${diffInHours}h ago`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays}d ago`;
    }
  };

  return (
    <div className={`bg-white rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200 cursor-pointer ${
      compact ? 'p-4' : 'p-6'
    }`} onClick={() => onView(issue)}>
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1 min-w-0">
          <h3 className={`font-semibold text-gray-900 line-clamp-2 ${
            compact ? 'text-base' : 'text-lg'
          }`}>
            {issue.title}
          </h3>
          {!compact && (
            <p className="text-gray-600 mt-2 line-clamp-2">{issue.description}</p>
          )}
        </div>
        
        {/* Severity Indicator */}
        <div className={`ml-3 px-2 py-1 rounded-full text-xs font-medium whitespace-nowrap ${getSeverityColor(issue.severity)}`}>
          {issue.severity.charAt(0).toUpperCase() + issue.severity.slice(1)}
        </div>
      </div>

      {/* Tags */}
      <div className="flex flex-wrap items-center gap-2 mb-3">
        <span className="bg-gray-100 px-2 py-1 rounded-full text-xs font-medium text-gray-700">
          {issue.category}
        </span>
        <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(issue.status)}`}>
          {issue.status}
        </span>
        {issue.images && issue.images.length > 0 && (
          <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
            📷 {issue.images.length}
          </span>
        )}
      </div>

      {/* Location and Meta Info */}
      <div className={`flex items-center justify-between text-sm text-gray-500 ${
        compact ? 'space-y-1 flex-col items-start' : ''
      }`}>
        <div className={`flex items-center space-x-4 ${compact ? 'flex-wrap gap-2' : ''}`}>
          {showLocation && (
            <span className="flex items-center space-x-1">
              <MapPin className="w-3 h-3" />
              <span>{issue.location.municipality}, Ward {issue.location.ward}</span>
            </span>
          )}
          <span className="flex items-center space-x-1">
            <Calendar className="w-3 h-3" />
            <span>{formatTimeAgo(issue.createdAt)}</span>
          </span>
          <span className="flex items-center space-x-1">
            <User className="w-3 h-3" />
            <span>{issue.isAnonymous ? 'Anonymous' : issue.reportedBy}</span>
          </span>
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-3">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onUpvote(issue.id);
            }}
            className="flex items-center space-x-1 text-gray-600 hover:text-red-600 transition-colors"
          >
            <ThumbsUp className="w-4 h-4" />
            <span>{issue.upvotes}</span>
          </button>
          <span className="flex items-center space-x-1 text-gray-600">
            <MessageSquare className="w-4 h-4" />
            <span>{issue.comments}</span>
          </span>
          <span className="flex items-center space-x-1 text-blue-600 font-medium">
            <Eye className="w-4 h-4" />
            <span>View</span>
          </span>
        </div>
      </div>
    </div>
  );
};

export default IssueCard;