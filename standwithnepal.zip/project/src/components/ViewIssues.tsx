import React, { useState } from 'react';
import { Search, Filter, MapPin, ThumbsUp, MessageCircle, Calendar, Eye, Map } from 'lucide-react';
import { useDebounce } from '../hooks/useDebounce';
import { Issue, FilterOptions } from '../types';
import { ISSUE_CATEGORIES } from '../utils/constants';
import LoadingSpinner from './LoadingSpinner';
import MapView from './MapView';
import IssueDetails from './IssueDetails';
import IssueCard from './IssueCard';
import { User } from '../types';

interface ViewIssuesProps {
  user: User | null;
}

const ViewIssues: React.FC<ViewIssuesProps> = ({ user }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounce(searchTerm, 300);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [selectedSeverity, setSelectedSeverity] = useState('');
  const [sortBy, setSortBy] = useState('recent');
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const filterOptions = {
    category: selectedCategory,
    status: selectedStatus,
    severity: selectedSeverity,
    location: '',
    dateRange: '',
    sortBy: sortBy
  };

  // Mock data - in real app, this would come from API
  const issues: Issue[] = [
    {
      id: '1',
      title: 'Broken streetlight near Ratna Park',
      description: 'The streetlight has been broken for over a week, making the area unsafe during night hours.',
      category: 'Electricity',
      location: {
        province: 'Bagmati Province',
        district: 'Kathmandu',
        municipality: 'Kathmandu Metropolitan City',
        ward: '1'
      },
      status: 'In Progress',
      severity: 'high',
      upvotes: 23,
      comments: 5,
      reportedBy: 'Sita Sharma',
      isAnonymous: false,
      createdAt: '2024-01-15T10:30:00Z',
      updatedAt: '2024-01-16T14:20:00Z',
      images: [],
      coordinates: { lat: 27.7172, lng: 85.3240 }
    },
    {
      id: '2',
      title: 'Water shortage in Tarkeshwar area',
      description: 'Residents have been without water supply for 3 days. The local water tank seems to be empty.',
      category: 'Water Supply',
      location: {
        province: 'Bagmati Province',
        district: 'Kathmandu',
        municipality: 'Kathmandu Metropolitan City',
        ward: '12'
      },
      status: 'Acknowledged',
      severity: 'urgent',
      upvotes: 45,
      comments: 12,
      reportedBy: 'Anonymous',
      isAnonymous: true,
      createdAt: '2024-01-14T08:15:00Z',
      updatedAt: '2024-01-15T09:45:00Z',
      images: [],
      coordinates: { lat: 27.7172, lng: 85.3240 }
    },
    {
      id: '3',
      title: 'Potholes on Ring Road causing accidents',
      description: 'Multiple large potholes have formed on the Ring Road section near Koteshwor. Several minor accidents have occurred.',
      category: 'Road Infrastructure',
      location: {
        province: 'Bagmati Province',
        district: 'Lalitpur',
        municipality: 'Lalitpur Metropolitan City',
        ward: '3'
      },
      status: 'New',
      severity: 'high',
      upvotes: 78,
      comments: 8,
      reportedBy: 'Ram Bahadur',
      isAnonymous: false,
      createdAt: '2024-01-13T16:45:00Z',
      updatedAt: '2024-01-13T16:45:00Z',
      images: [],
      coordinates: { lat: 27.7172, lng: 85.3240 }
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'New':
        return 'bg-yellow-100 text-yellow-800';
      case 'Acknowledged':
        return 'bg-blue-100 text-blue-800';
      case 'In Progress':
        return 'bg-orange-100 text-orange-800';
      case 'Resolved':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low':
        return 'bg-green-100 text-green-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'high':
        return 'bg-orange-100 text-orange-800';
      case 'urgent':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 24) {
      return `${diffInHours} hours ago`;
    } else {
      const diffInDays = Math.floor(diffInHours / 24);
      return `${diffInDays} days ago`;
    }
  };

  const filteredIssues = issues.filter(issue => {
    const matchesSearch = issue.title.toLowerCase().includes(debouncedSearchTerm.toLowerCase()) ||
                         issue.description.toLowerCase().includes(debouncedSearchTerm.toLowerCase());
    const matchesCategory = !selectedCategory || issue.category === selectedCategory;
    const matchesStatus = !selectedStatus || issue.status === selectedStatus;
    const matchesSeverity = !selectedSeverity || issue.severity === selectedSeverity;
    
    return matchesSearch && matchesCategory && matchesStatus && matchesSeverity;
  });

  const sortedIssues = [...filteredIssues].sort((a, b) => {
    switch (sortBy) {
      case 'upvotes':
        return b.upvotes - a.upvotes;
      case 'recent':
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      case 'severity':
        const severityOrder = { urgent: 4, high: 3, medium: 2, low: 1 };
        return severityOrder[b.severity] - severityOrder[a.severity];
      default:
        return 0;
    }
  });

  const handleIssueSelect = (issue: Issue) => {
    setSelectedIssue(issue);
  };

  const handleUpvote = (issueId: string) => {
    // In real app, this would call API to upvote
    console.log('Upvoting issue:', issueId);
  };

  const handleComment = (issueId: string, comment: string) => {
    // In real app, this would call API to add comment
    console.log('Adding comment to issue:', issueId, comment);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">View Issues</h1>
        <p className="text-gray-600">
          Browse and track issues reported by citizens in your area.
        </p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 lg:space-x-4">
          {/* Search */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Search issues..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
            />
          </div>

          {/* View Toggle */}
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setViewMode('list')}
              className={`p-2 rounded-lg ${viewMode === 'list' ? 'bg-red-100 text-red-600' : 'text-gray-400 hover:bg-gray-100'}`}
              title="List View"
            >
              <Eye className="w-5 h-5" />
            </button>
            <button
              onClick={() => setViewMode('map')}
              className={`p-2 rounded-lg ${viewMode === 'map' ? 'bg-red-100 text-red-600' : 'text-gray-400 hover:bg-gray-100'}`}
              title="Map View"
            >
              <Map className="w-5 h-5" />
            </button>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
            >
              <Filter className="w-4 h-4" />
              <span>Filters</span>
            </button>
          </div>
        </div>

        {/* Advanced Filters */}
        {showFilters && (
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                >
                  <option value="">All Categories</option>
                  {ISSUE_CATEGORIES.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                >
                  <option value="">All Statuses</option>
                  <option value="New">New</option>
                  <option value="Acknowledged">Acknowledged</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Resolved">Resolved</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Severity</label>
                <select
                  value={selectedSeverity}
                  onChange={(e) => setSelectedSeverity(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                >
                  <option value="">All Severities</option>
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                  <option value="urgent">Urgent</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Sort By</label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                >
                  <option value="recent">Most Recent</option>
                  <option value="upvotes">Most Upvoted</option>
                  <option value="severity">By Severity</option>
                </select>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Results */}
      <div className="mb-4 flex items-center justify-between">
        <p className="text-gray-600">
          Showing {sortedIssues.length} of {issues.length} issues
        </p>
      </div>

      {/* Issues List */}
      {viewMode === 'list' && (
        <>
          {isLoading ? (
            <div className="flex justify-center py-12">
              <LoadingSpinner size="lg" />
            </div>
          ) : (
            <div className="space-y-4">
              {sortedIssues.map((issue) => (
                <IssueCard
                  key={issue.id}
                  issue={issue}
                  onView={handleIssueSelect}
                  onUpvote={handleUpvote}
                  showLocation={true}
                  compact={false}
                />
              ))}
            </div>
          )}
        </>
      )}

      {/* Map View */}
      {viewMode === 'map' && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <MapView
            issues={sortedIssues.map(issue => ({
              ...issue,
              location: {
                ...issue.location,
                coordinates: { lat: 27.7172 + Math.random() * 0.1, lng: 85.3240 + Math.random() * 0.1 }
              }
            }))}
            onIssueSelect={handleIssueSelect}
            selectedCategory={selectedCategory}
            selectedStatus={selectedStatus}
          />
        </div>
      )}

      {/* Empty State */}
      {sortedIssues.length === 0 && (
        <div className="text-center py-16">
          <Eye className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Issues Found</h3>
          <p className="text-gray-600">
            Try adjusting your search criteria or filters to find relevant issues.
          </p>
        </div>
      )}

      {/* Issue Details Modal */}
      {selectedIssue && (
        <IssueDetails
          issue={selectedIssue}
          isOpen={!!selectedIssue}
          onClose={() => setSelectedIssue(null)}
          onUpvote={handleUpvote}
          onComment={handleComment}
          userRole={user?.role || 'citizen'}
        />
      )}
    </div>
  );
};

export default ViewIssues;