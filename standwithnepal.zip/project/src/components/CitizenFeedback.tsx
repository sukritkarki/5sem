import React, { useState } from 'react';
import { Star, ThumbsUp, ThumbsDown, MessageCircle, Send } from 'lucide-react';

interface CitizenFeedbackProps {
  issueId: string;
  issueStatus: 'New' | 'Acknowledged' | 'In Progress' | 'Resolved';
  onFeedbackSubmit: (feedback: {
    rating: number;
    satisfaction: 'satisfied' | 'neutral' | 'dissatisfied';
    comment: string;
  }) => void;
}

const CitizenFeedback: React.FC<CitizenFeedbackProps> = ({
  issueId,
  issueStatus,
  onFeedbackSubmit
}) => {
  const [showFeedbackForm, setShowFeedbackForm] = useState(false);
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [satisfaction, setSatisfaction] = useState<'satisfied' | 'neutral' | 'dissatisfied' | ''>('');
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0 || !satisfaction) return;

    setIsSubmitting(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 1000));
      onFeedbackSubmit({
        rating,
        satisfaction: satisfaction as 'satisfied' | 'neutral' | 'dissatisfied',
        comment
      });
      setShowFeedbackForm(false);
      // Reset form
      setRating(0);
      setSatisfaction('');
      setComment('');
    } catch (error) {
      console.error('Error submitting feedback:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Only show feedback option for resolved issues or issues in progress
  if (issueStatus === 'New') {
    return null;
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
          <MessageCircle className="w-5 h-5 text-green-600" />
          <span>Citizen Feedback</span>
        </h3>
        
        {!showFeedbackForm && (
          <button
            onClick={() => setShowFeedbackForm(true)}
            className="text-green-600 hover:text-green-700 font-medium text-sm"
          >
            Provide Feedback
          </button>
        )}
      </div>

      {!showFeedbackForm ? (
        <div className="text-center py-6">
          <MessageCircle className="w-12 h-12 text-gray-400 mx-auto mb-3" />
          <p className="text-gray-600 mb-2">Share your experience</p>
          <p className="text-sm text-gray-500">
            Help us improve by rating the government response to this issue
          </p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Rating */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              How would you rate the government response? *
            </label>
            <div className="flex items-center space-x-1">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoveredRating(star)}
                  onMouseLeave={() => setHoveredRating(0)}
                  className="p-1 transition-colors"
                >
                  <Star
                    className={`w-8 h-8 ${
                      star <= (hoveredRating || rating)
                        ? 'text-yellow-400 fill-current'
                        : 'text-gray-300'
                    }`}
                  />
                </button>
              ))}
              <span className="ml-3 text-sm text-gray-600">
                {rating > 0 && (
                  <>
                    {rating === 1 && 'Very Poor'}
                    {rating === 2 && 'Poor'}
                    {rating === 3 && 'Average'}
                    {rating === 4 && 'Good'}
                    {rating === 5 && 'Excellent'}
                  </>
                )}
              </span>
            </div>
          </div>

          {/* Satisfaction */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-3">
              Overall satisfaction with the resolution *
            </label>
            <div className="flex items-center space-x-4">
              <button
                type="button"
                onClick={() => setSatisfaction('satisfied')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg border transition-colors ${
                  satisfaction === 'satisfied'
                    ? 'bg-green-50 border-green-200 text-green-800'
                    : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                }`}
              >
                <ThumbsUp className="w-4 h-4" />
                <span>Satisfied</span>
              </button>
              
              <button
                type="button"
                onClick={() => setSatisfaction('neutral')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg border transition-colors ${
                  satisfaction === 'neutral'
                    ? 'bg-yellow-50 border-yellow-200 text-yellow-800'
                    : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                }`}
              >
                <MessageCircle className="w-4 h-4" />
                <span>Neutral</span>
              </button>
              
              <button
                type="button"
                onClick={() => setSatisfaction('dissatisfied')}
                className={`flex items-center space-x-2 px-4 py-2 rounded-lg border transition-colors ${
                  satisfaction === 'dissatisfied'
                    ? 'bg-red-50 border-red-200 text-red-800'
                    : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                }`}
              >
                <ThumbsDown className="w-4 h-4" />
                <span>Dissatisfied</span>
              </button>
            </div>
          </div>

          {/* Comment */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Additional Comments (Optional)
            </label>
            <textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              rows={3}
              placeholder="Share your thoughts about the government response and resolution process..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-green-500"
            />
          </div>

          {/* Submit Buttons */}
          <div className="flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={() => setShowFeedbackForm(false)}
              className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={rating === 0 || !satisfaction || isSubmitting}
              className="flex items-center space-x-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-4 h-4" />
              <span>{isSubmitting ? 'Submitting...' : 'Submit Feedback'}</span>
            </button>
          </div>
        </form>
      )}

      {/* Feedback Guidelines */}
      {showFeedbackForm && (
        <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <h4 className="font-medium text-blue-900 mb-2">Your feedback helps:</h4>
          <ul className="text-sm text-blue-800 space-y-1">
            <li>• Improve government response times and quality</li>
            <li>• Identify areas needing better attention</li>
            <li>• Build accountability and transparency</li>
            <li>• Help other citizens understand resolution effectiveness</li>
          </ul>
        </div>
      )}
    </div>
  );
};

export default CitizenFeedback;