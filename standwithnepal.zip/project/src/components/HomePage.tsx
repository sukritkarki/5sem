import React from 'react';
import { MessageSquare, Eye, Users, Map, Award, Shield } from 'lucide-react';
import TrendingIssues from './TrendingIssues';
import IssueCard from './IssueCard';

interface User {
  id: string;
  name: string;
  email: string;
  role: 'citizen' | 'government' | 'admin';
  jurisdiction?: {
    province: string;
    district: string;
    municipality: string;
    ward: string;
  };
  isVerified: boolean;
}

interface HomePageProps {
  user: User | null;
}

const HomePage: React.FC<HomePageProps> = ({ user }) => {
  const stats = [
    { label: 'Issues Reported', value: '2,847', icon: MessageSquare, color: 'text-blue-600' },
    { label: 'Issues Resolved', value: '1,923', icon: Award, color: 'text-green-600' },
    { label: 'Active Citizens', value: '12,450', icon: Users, color: 'text-purple-600' },
    { label: 'Government Officials', value: '156', icon: Shield, color: 'text-red-600' },
  ];

  const recentIssues = [
    {
      id: 1,
      title: 'Broken streetlight near Ratna Park',
      description: 'The streetlight has been broken for over a week, making the area unsafe during night hours.',
      category: 'Electricity',
      location: 'Kathmandu Ward-1',
      location: {
        province: 'Bagmati Province',
        district: 'Kathmandu',
        municipality: 'Kathmandu Metropolitan City',
        ward: '1'
      },
      status: 'In Progress' as const,
      severity: 'high' as const,
      upvotes: 23,
      comments: 5,
      reportedBy: 'Sita Sharma',
      isAnonymous: false,
      createdAt: '2024-01-15T10:30:00Z',
    },
    {
      id: 2,
      title: 'Water shortage in Tarkeshwar area',
      description: 'Residents have been without water supply for 3 days. The local water tank seems to be empty.',
      category: 'Water Supply',
      location: 'Kathmandu Ward-12',
      location: {
        province: 'Bagmati Province',
        district: 'Kathmandu',
        municipality: 'Kathmandu Metropolitan City',
        ward: '12'
      },
      status: 'Acknowledged' as const,
      severity: 'urgent' as const,
      upvotes: 45,
      comments: 12,
      reportedBy: 'Anonymous',
      isAnonymous: true,
      createdAt: '2024-01-14T08:15:00Z',
    },
    {
      id: 3,
      title: 'Potholes on Ring Road',
      description: 'Multiple large potholes have formed on the Ring Road section near Koteshwor.',
      category: 'Road Infrastructure',
      location: 'Lalitpur Ward-3',
      location: {
        province: 'Bagmati Province',
        district: 'Lalitpur',
        municipality: 'Lalitpur Metropolitan City',
        ward: '3'
      },
      status: 'New' as const,
      severity: 'high' as const,
      upvotes: 78,
      comments: 8,
      reportedBy: 'Ram Bahadur',
      isAnonymous: false,
      createdAt: '2024-01-13T16:45:00Z',
    }
  ];

  const handleIssueView = (issue: any) => {
    console.log('Viewing issue:', issue);
    // In real app, this would navigate to issue details
  };

  const handleUpvote = (issueId: string) => {
    console.log('Upvoting issue:', issueId);
    // In real app, this would call API to upvote
  };

  const features = [
    {
      icon: MessageSquare,
      title: 'Report Issues',
      description: 'Submit local problems with photos and location details',
      color: 'bg-red-50 text-red-600'
    },
    {
      icon: Eye,
      title: 'Track Progress',
      description: 'Monitor the status of reported issues and government responses',
      color: 'bg-blue-50 text-blue-600'
    },
    {
      icon: Map,
      title: 'Location-Based',
      description: 'View issues specific to your ward, municipality, or district',
      color: 'bg-green-50 text-green-600'
    },
    {
      icon: Users,
      title: 'Community Voice',
      description: 'Upvote important issues and engage with your community',
      color: 'bg-purple-50 text-purple-600'
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Hero Section */}
      <div className="text-center mb-12">
        <div className="mb-6">
          <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Stand with Nepal</h1>
          <h2 className="text-2xl font-semibold text-red-600 mb-4">नागरिक आवाज मञ्च</h2>
          <p className="text-lg text-gray-600 mb-2">Citizen Voice Platform</p>
        </div>
        
        <p className="text-lg text-gray-700 max-w-3xl mx-auto mb-8">
          Empowering citizens to freely express opinions, report local issues, and suggest improvements. 
          Connecting communities with their representatives for better governance.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <button className="bg-red-600 text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-red-700 transition-colors flex items-center justify-center space-x-2">
            <MessageSquare className="w-5 h-5" />
            <span>Report an Issue</span>
          </button>
          <button className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-medium hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2">
            <Map className="w-5 h-5" />
            <span>View Issues</span>
          </button>
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-lg p-6 shadow-sm border border-gray-200 hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-1">{stat.value}</p>
                </div>
                <div className={`p-3 rounded-lg bg-gray-50`}>
                  <Icon className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Features Section */}
      <div className="mb-12">
        <h3 className="text-2xl font-bold text-gray-900 text-center mb-8">How It Works</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div key={index} className="text-center p-6">
                <div className={`w-12 h-12 ${feature.color} rounded-lg flex items-center justify-center mx-auto mb-4`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h4 className="text-lg font-semibold text-gray-900 mb-2">{feature.title}</h4>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Recent Issues */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Recent Issues */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-gray-200">
            <h3 className="text-lg font-semibold text-gray-900">Recent Issues</h3>
          </div>
          <div className="divide-y divide-gray-200">
            {recentIssues.map((issue) => (
              <div key={issue.id} className="p-4">
                <IssueCard
                  issue={issue}
                  onView={handleIssueView}
                  onUpvote={handleUpvote}
                  showLocation={true}
                  compact={true}
                />
              </div>
            ))}
          </div>
          <div className="px-6 py-4 bg-gray-50 text-center">
            <button className="text-blue-600 hover:text-blue-700 font-medium">
              View All Issues
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

        {/* Trending Issues */}
        <TrendingIssues timeframe="week" limit={5} showFilters={false} />
export default HomePage;