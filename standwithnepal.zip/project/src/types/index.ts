import { ISSUE_CATEGORIES, ISSUE_STATUSES, SEVERITY_LEVELS, USER_ROLES } from '../utils/constants';

export interface User {
  id: string;
  name: string;
  email: string;
  role: typeof USER_ROLES[number];
  jurisdiction?: {
    province: string;
    district: string;
    municipality: string;
    ward: string;
  };
  isVerified: boolean;
  createdAt: string;
  lastActive: string;
  status: 'active' | 'suspended' | 'pending';
}

export interface Issue {
  id: string;
  title: string;
  description: string;
  category: typeof ISSUE_CATEGORIES[number];
  location: {
    province: string;
    district: string;
    municipality: string;
    ward: string;
    coordinates?: {
      lat: number;
      lng: number;
    };
  };
  status: typeof ISSUE_STATUSES[number];
  severity: typeof SEVERITY_LEVELS[number];
  upvotes: number;
  comments: number;
  reportedBy: string;
  isAnonymous: boolean;
  createdAt: string;
  updatedAt: string;
  images?: string[];
  governmentResponse?: string;
  assignedDepartment?: string;
  statusHistory?: StatusUpdate[];
}

export interface StatusUpdate {
  id: string;
  status: typeof ISSUE_STATUSES[number];
  timestamp: string;
  updatedBy: string;
  message?: string;
  department?: string;
}

export interface Comment {
  id: string;
  author: string;
  content: string;
  createdAt: string;
  isOfficial: boolean;
}

export interface Notification {
  id: string;
  type: 'success' | 'warning' | 'info' | 'error';
  title: string;
  message: string;
  timestamp: string;
  isRead: boolean;
  actionUrl?: string;
  actionText?: string;
}

export interface FilterOptions {
  category: string;
  status: string;
  severity: string;
  location: string;
  dateRange: string;
  sortBy: string;
}

export interface StatItem {
  label: string;
  value: string | number;
  change?: {
    value: number;
    type: 'increase' | 'decrease' | 'neutral';
    period: string;
  };
  icon: React.ComponentType<any>;
  color: string;
  bgColor: string;
}